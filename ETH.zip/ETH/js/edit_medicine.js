document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('.form-container');
    
    form.addEventListener('submit', function(e) {
        const name = document.getElementById('name').value.trim();
        const price = parseFloat(document.getElementById('price').value);
        const quantity = parseInt(document.getElementById('quantity').value);
        const category = document.getElementById('category_id').value;
        const supplier = document.getElementById('supplier_id').value;
        
        let errors = [];
        
        if (!name) {
            errors.push("Medicine name is required");
        }
        
        if (isNaN(price) || price <= 0) {
            errors.push("Please enter a valid price");
        }
        
        if (isNaN(quantity) || quantity < 0) {
            errors.push("Please enter a valid quantity");
        }
        
        if (!category) {
            errors.push("Please select a category");
        }
        
        if (!supplier) {
            errors.push("Please select a supplier");
        }
        
        if (errors.length > 0) {
            e.preventDefault();
            alert(errors.join("\n"));
        }
    });
});

function confirmDelete() {
    const message = 'What would you like to do with this medicine?\n\n' +
                   '1. Delete (only if not used in any orders)\n' +
                   '2. Mark as inactive (can be used if medicine is in orders)\n' +
                   '3. Cancel';
    
    const choice = prompt(message, '1');
    
    if (choice === '1') {
        document.getElementById('mark_inactive').value = '0';
        document.getElementById('deleteForm').submit();
    } else if (choice === '2') {
        document.getElementById('mark_inactive').value = '1';
        document.getElementById('deleteForm').submit();
    }
} 