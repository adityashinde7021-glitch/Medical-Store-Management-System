-- First check if customers table exists, if not create it
CREATE TABLE IF NOT EXISTS customers (
	id INT PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(100) NOT NULL,
	phone VARCHAR(20) NOT NULL,
	email VARCHAR(100),
	address TEXT NOT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Add indexes for better performance
ALTER TABLE customers
ADD INDEX idx_customer_name (name),
ADD INDEX idx_customer_phone (phone),
ADD INDEX idx_customer_email (email);

-- Update existing customers table if it exists to add new columns
ALTER TABLE customers
MODIFY COLUMN phone VARCHAR(20) NOT NULL,
MODIFY COLUMN email VARCHAR(100),
ADD COLUMN IF NOT EXISTS address TEXT NOT NULL AFTER email,
ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Add foreign key to orders table if it exists
ALTER TABLE orders
ADD COLUMN IF NOT EXISTS customer_id INT,
ADD FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL;