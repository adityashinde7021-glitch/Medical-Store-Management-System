<?php
require_once "config.php";

try {
    $sql = "ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50) AFTER total_amount";
    $pdo->exec($sql);
    echo "Database updated successfully";
} catch(PDOException $e) {
    echo "Error updating database: " . $e->getMessage();
}
?> 