<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
	header("location: login.php");
	exit;
}

// Initialize variables
$total_amount = 0;
$subtotal = 0;
$tax = 0;
$items = [];
$order_id = null;

// Get order details from POST data
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['payment_method'])) {
	$total_amount = isset($_POST['total_amount']) ? floatval($_POST['total_amount']) : 0;
	$subtotal = isset($_POST['subtotal']) ? floatval($_POST['subtotal']) : 0;
	$tax = isset($_POST['tax']) ? floatval($_POST['tax']) : 0;
	$items = isset($_POST['items']) ? json_decode($_POST['items'], true) : [];

	try {
		// Begin transaction
		$pdo->beginTransaction();
		
		// Create new order
		$sql = "INSERT INTO orders (customer_name, total_amount, status) VALUES (?, ?, 'Pending')";
		$stmt = $pdo->prepare($sql);
		$stmt->execute([$_SESSION['username'], $total_amount]);
		$order_id = $pdo->lastInsertId();
		
		// Store in session for persistence
		$_SESSION['order_details'] = [
			'total_amount' => $total_amount,
			'subtotal' => $subtotal,
			'tax' => $tax,
			'items' => $items,
			'order_id' => $order_id
		];
		
		$pdo->commit();
	} catch(PDOException $e) {
		$pdo->rollBack();
		$error = "Order creation failed. Please try again.";
	}
} elseif (isset($_SESSION['order_details'])) {
	// Retrieve from session if available
	$total_amount = $_SESSION['order_details']['total_amount'];
	$subtotal = $_SESSION['order_details']['subtotal'];
	$tax = $_SESSION['order_details']['tax'];
	$items = $_SESSION['order_details']['items'];
	$order_id = $_SESSION['order_details']['order_id'];
}

// Process payment
if($_SERVER["REQUEST_METHOD"] == "POST") {
	$payment_method = $_POST['payment_method'];
	$amount = $_POST['amount'];
	$order_id = $_POST['order_id'];
	
	try {
		// Begin transaction
		$pdo->beginTransaction();
		
		// Insert into payments table
		$sql = "INSERT INTO payments (order_id, amount, payment_method, screenshot_path, payment_status) VALUES (?, ?, ?, NULL, 'pending')";
		$stmt = $pdo->prepare($sql);
		$stmt->execute([$order_id, $amount, $payment_method]);
		$payment_id = $pdo->lastInsertId();
		
		// Update order status
		$sql = "UPDATE orders SET status = 'Processing' WHERE order_id = ?";
		$stmt = $pdo->prepare($sql);
		$stmt->execute([$order_id]);
		
		// Commit transaction
		$pdo->commit();
		
		// Redirect based on payment method
		switch($payment_method) {
			case 'qr_code':
				$_SESSION['payment_id'] = $payment_id;
				header("Location: screenshot.php");
				exit;
			case 'credit_card':
				// Redirect to credit card processing
				header("Location: credit_card_process.php?payment_id=" . $payment_id);
				exit;
			default:
				$_SESSION['payment_id'] = $payment_id;
				header("Location: screenshot.php");
				exit;
		}
	} catch(PDOException $e) {
		$pdo->rollBack();
		$error = "Payment processing failed. Please try again.";
	}
}

// Fetch recent payments
$recent_payments = [];
$sql = "SELECT p.*, o.customer_name 
		FROM payments p 
		JOIN orders o ON p.order_id = o.order_id 
		ORDER BY p.payment_date DESC LIMIT 5";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$recent_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Payment - Medical Shop</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<style>
		.payment-option {
			border: 2px solid #ddd;
			padding: 20px;
			margin: 10px;
			border-radius: 10px;
			cursor: pointer;
			transition: all 0.3s ease;
		}
		.payment-option:hover {
			border-color: #007bff;
			transform: translateY(-5px);
		}
		.payment-option.selected {
			border-color: #28a745;
			background-color: #f8fff8;
		}
		.payment-icon {
			font-size: 2em;
			margin-bottom: 10px;
		}
		.currency::before {
			content: '₹';
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="medical.php">Medical Shop</a>
		<div class="navbar-nav ml-auto">
			<a href="medical.php" class="btn btn-primary mr-2">Dashboard</a>
			<a href="logout.php" class="btn btn-danger">Logout</a>
		</div>
	</nav>

	<div class="container mt-5">
		<?php if(isset($error)): ?>
			<div class="alert alert-danger"><?php echo $error; ?></div>
		<?php endif; ?>

		<div class="row">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header">
						<h4>Payment Details</h4>
					</div>
					<div class="card-body">
						<form id="paymentForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
							<input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
							<input type="hidden" name="amount" value="<?php echo $total_amount; ?>">
							<input type="hidden" name="payment_method" id="payment_method">
							
							<div class="form-group">
								<label>Amount to Pay</label>
								<input type="text" class="form-control" value="<?php echo number_format($total_amount, 2); ?>" readonly>
							</div>

							<div class="row">
								<div class="col-md-4">
									<div class="payment-option" data-method="qr_code">
										<div class="text-center">
											<i class="fas fa-qrcode payment-icon"></i>
											<h5>QR Code</h5>
											<p class="mb-0">Scan & Pay</p>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="payment-option" data-method="upi">
										<div class="text-center">
											<i class="fas fa-mobile-alt payment-icon"></i>
											<h5>UPI</h5>
											<p class="mb-0">Google Pay/PhonePe/PayTM</p>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="payment-option" data-method="credit_card">
										<div class="text-center">
											<i class="fas fa-credit-card payment-icon"></i>
											<h5>Card Payment</h5>
											<p class="mb-0">Credit/Debit Card</p>
										</div>
									</div>
								</div>
							</div>

							<!-- Add QR code container -->
							<div id="qr-code-container" style="display: none;" class="text-center mt-4">
								<img src="qr.jpg" alt="QR Code" style="max-width: 300px;" />
								<p class="mt-2">Scan this QR code to make payment</p>
							</div>


							<div class="text-center mt-4">
								<button type="button" class="btn btn-primary" id="payButton" onclick="window.location.href='screenshot.php'">
									<i class="fas fa-camera"></i> Upload Payment Screenshot
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>

			<div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h4>Order Summary</h4>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <tr>
                                <td>Subtotal:</td>
                                <td class="text-right currency"><?php echo number_format($subtotal, 2); ?></td>
                            </tr>
                            <tr>
                                <td>Tax:</td>
                                <td class="text-right currency"><?php echo number_format($tax, 2); ?></td>
                            </tr>
                            <tr>
                                <th>Total:</th>
                                <th class="text-right currency"><?php echo number_format($total_amount, 2); ?></th>
                            </tr>
                        </table>

					</div>
				</div>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	
	<script>
		$(document).ready(function() {
			$('.payment-option').click(function() {
				$('.payment-option').removeClass('selected');
				$(this).addClass('selected');
				var method = $(this).data('method');
				$('#payment_method').val(method);
				$('#payButton').prop('disabled', false);
				
				// Hide QR code container when switching payment methods
				$('#qr-code-container').hide();
				
				// Show QR code if QR payment method is selected
				if (method === 'qr_code') {
					$('#qr-code-container').show();
				}
			});

			// Handle form submission
			$('#paymentForm').submit(function(e) {
				var selectedMethod = $('#payment_method').val();
				
				if (!selectedMethod) {
					e.preventDefault();
					alert('Please select a payment method');
					return;
				}
			});
		});

	</script>
</body>
</html>