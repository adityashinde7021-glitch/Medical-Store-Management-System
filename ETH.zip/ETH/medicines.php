<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// First, let's add the status column to handle soft deletes
// Add this near the top with other SQL operations

// Modify the delete operation to use soft delete
if(isset($_GET["delete_id"]) && !empty($_GET["delete_id"])){
    // First check if medicine exists
    $check_sql = "SELECT id FROM medicines WHERE id = :id AND status = 'active'";
    $stmt = $pdo->prepare($check_sql);
    $stmt->bindParam(":id", $_GET["delete_id"], PDO::PARAM_INT);
    $stmt->execute();
    
    if($stmt->rowCount() == 0){
        $_SESSION['error'] = "Medicine not found or already deleted.";
        header("location: medicines.php");
        exit();
    }
    
    // Instead of DELETE, update the status and set quantity to 0
    $sql = "UPDATE medicines SET status = 'deleted', quantity = 0 WHERE id = :id";
    if($stmt = $pdo->prepare($sql)){
        $stmt->bindParam(":id", $_GET["delete_id"], PDO::PARAM_INT);
        if($stmt->execute()){
            $_SESSION['success'] = "Medicine removed successfully.";
            header("location: medicines.php");
            exit();
        } else {
            $_SESSION['error'] = "Oops! Something went wrong. Please try again later.";
            header("location: medicines.php");
            exit();
        }
    }
    unset($stmt);
}

// Process form data when submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $name = trim($_POST["name"]);
    $description = trim($_POST["description"]);
    $price = trim($_POST["price"]);
    $quantity = trim($_POST["quantity"]);
    
    // Check if this is an edit operation
    if(isset($_POST["id"]) && !empty($_POST["id"])){
        // Update record
        $sql = "UPDATE medicines SET name=:name, description=:description, price=:price, quantity=:quantity WHERE id=:id";
        if($stmt = $pdo->prepare($sql)){
            $stmt->bindParam(":name", $name, PDO::PARAM_STR);
            $stmt->bindParam(":description", $description, PDO::PARAM_STR);
            $stmt->bindParam(":price", $price);
            $stmt->bindParam(":quantity", $quantity, PDO::PARAM_INT);
            $stmt->bindParam(":id", $_POST["id"], PDO::PARAM_INT);
            
            if($stmt->execute()){
                header("location: medicines.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
        unset($stmt);
    } else {
        // Insert new record
        $sql = "INSERT INTO medicines (name, description, price, quantity) VALUES (:name, :description, :price, :quantity)";
        if($stmt = $pdo->prepare($sql)){
            $stmt->bindParam(":name", $name, PDO::PARAM_STR);
            $stmt->bindParam(":description", $description, PDO::PARAM_STR);
            $stmt->bindParam(":price", $price);
            $stmt->bindParam(":quantity", $quantity, PDO::PARAM_INT);
            
            if($stmt->execute()){
                header("location: medicines.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
        unset($stmt);
    }
}

// Fetch medicine details if edit mode
$medicine = null;
if(isset($_GET["edit_id"]) && !empty($_GET["edit_id"])){
    $sql = "SELECT * FROM medicines WHERE id = :id";
    if($stmt = $pdo->prepare($sql)){
        $stmt->bindParam(":id", $_GET["edit_id"], PDO::PARAM_INT);
        if($stmt->execute()){
            $medicine = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Medicines - Medical Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <?php 
        if(isset($_SESSION['success'])){
            echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
            unset($_SESSION['success']);
        }
        if(isset($_SESSION['error'])){
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Manage Medicines</h2>
                    <div>
                        <a href="logout.php" class="btn btn-danger">Logout</a>
                    </div>
                </div>

                <!-- Add/Edit Medicine Form -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h4><?php echo $medicine ? 'Edit Medicine' : 'Add New Medicine'; ?></h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <?php if($medicine) { ?>
                                <input type="hidden" name="id" value="<?php echo $medicine['id']; ?>">
                            <?php } ?>
                            
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control" required 
                                    value="<?php echo $medicine ? $medicine['name'] : ''; ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" class="form-control" required><?php echo $medicine ? $medicine['description'] : ''; ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label>Price</label>
                                <input type="number" step="0.01" name="price" class="form-control" required 
                                    value="<?php echo $medicine ? $medicine['price'] : ''; ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Quantity</label>
                                <input type="number" name="quantity" class="form-control" required 
                                    value="<?php echo $medicine ? $medicine['quantity'] : ''; ?>">
                            </div>
                            
                            <button type="submit" class="btn btn-primary"><?php echo $medicine ? 'Update' : 'Add'; ?> Medicine</button>
                            <?php if($medicine) { ?>
                                <a href="medicines.php" class="btn btn-secondary">Cancel</a>
                            <?php } ?>
                        </form>
                    </div>
                </div>

                <!-- Medicines List -->
                <div class="card">
                    <div class="card-header">
                        <h4>Medicines List</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM medicines WHERE status = 'active' ORDER BY name";
                                if($result = $pdo->query($sql)){
                                    while($row = $result->fetch()){
                                        echo "<tr>";
                                        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                                        echo "<td>" . htmlspecialchars($row['description']) . "</td>";
                                        echo "<td><span class='currency'>" . htmlspecialchars($row['price']) . "</span></td>";
                                        echo "<td>" . htmlspecialchars($row['quantity']) . "</td>";
                                        echo "<td>";
                                        echo "<a href='medicines.php?edit_id=" . $row['id'] . "' class='btn btn-sm btn-primary mr-2'><i class='fas fa-edit'></i> Edit</a>";
                                        echo "<a href='medicines.php?delete_id=" . $row['id'] . "' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this medicine?\")'><i class='fas fa-trash'></i> Delete</a>";
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>