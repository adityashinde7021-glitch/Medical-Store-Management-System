<?php
require_once "config.php";

if(isset($_GET['order_id']) && is_numeric($_GET['order_id'])) {
    $order_id = intval($_GET['order_id']);
    
    $sql = "SELECT total_amount FROM orders WHERE order_id = ?";
    if ($stmt = $pdo->prepare($sql)) {
        if ($stmt->execute([$order_id])) {
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($order) {
                echo json_encode(['amount' => $order['total_amount']]);
                exit;
            }
        }
    }
}

// If we get here, something went wrong
echo json_encode(['amount' => '0.00']); 