<?php
session_start();
require_once "config.php";

// Function to convert USD to INR
function convertToRupees($amount) {
    $conversion_rate = 83; // 1 USD = 83 INR (approximate)
    return $amount * $conversion_rate;
}

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Get total sales with error handling
$total_sales = 0;
try {
    $sql = "SELECT SUM(total_amount) as total_sales FROM orders WHERE status = 'Completed'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_sales = $result['total_sales'] ?? 0;
} catch(PDOException $e) {
    error_log("Error getting total sales: " . $e->getMessage());
}

// Get low stock items with error handling
$low_stock = [];
try {
    $sql = "SELECT * FROM medicines WHERE quantity <= 10 ORDER BY quantity ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $low_stock = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log("Error getting low stock items: " . $e->getMessage());
}

// Get recent orders with error handling
$recent_orders = [];
try {
    $sql = "SELECT * FROM orders ORDER BY order_date DESC LIMIT 5";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $recent_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log("Error getting recent orders: " . $e->getMessage());
}

// Get customers list with error handling
$customers = [];
try {
    $sql = "SELECT * FROM customers ORDER BY name ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log("Error getting customers: " . $e->getMessage());
}

// Handle customer deletion
if(isset($_POST['delete_customer']) && isset($_POST['customer_id'])) {
    try {
        $sql = "DELETE FROM customers WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$_POST['customer_id']]);
        header("Location: reports.php");
        exit;
    } catch(PDOException $e) {
        error_log("Error deleting customer: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reports - Medical Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="medical.php">Medical Shop</a>
        <div class="navbar-nav ml-auto">
            <a href="medical.php" class="btn btn-primary mr-2">Dashboard</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Reports Dashboard</h2>
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">Total Sales</h5>
                        <h2 class="card-text">₹<?php echo number_format(convertToRupees($total_sales), 2); ?></h2>
                    </div>
                </div>
            </div>
            
            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Low Stock Alert</h5>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Medicine Name</th>
                                    <th>Current Quantity</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($low_stock as $item): ?>
                                <tr>
                                    <td><?php echo $item['name']; ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>
                                        <?php if($item['quantity'] <= 5): ?>
                                            <span class="badge badge-danger">Critical</span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">Low</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Recent Orders</h5>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer Name</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recent_orders as $order): ?>
                                <tr>
                                    <td><?php echo $order['order_id']; ?></td>
                                    <td><?php echo $order['customer_name']; ?></td>
                                    <td><?php echo $order['order_date']; ?></td>
                                    <td>₹<?php echo number_format(convertToRupees($order['total_amount']), 2); ?></td>
                                    <td><?php echo $order['status']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Customer Management</h5>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($customers as $customer): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($customer['name']); ?></td>
                                    <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                    <td><?php echo htmlspecialchars($customer['phone']); ?></td>
                                    <td>
                                        <a href="edit_customer.php?id=<?php echo $customer['id']; ?>" 
                                           class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="customer_id" 
                                                   value="<?php echo $customer['id']; ?>">
                                            <button type="submit" name="delete_customer" 
                                                    class="btn btn-sm btn-danger" 
                                                    onclick="return confirm('Are you sure you want to delete this customer?');">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>