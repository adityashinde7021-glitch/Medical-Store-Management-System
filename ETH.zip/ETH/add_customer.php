<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Validation function
function validateCustomerData($data) {
    $errors = [];
    
    // Validate name (required, 2-100 characters)
    if (empty(trim($data['name']))) {
        $errors['name'] = "Customer name is required";
    } elseif (strlen($data['name']) < 2 || strlen($data['name']) > 100) {
        $errors['name'] = "Name must be between 2 and 100 characters";
    }
    
    // Validate phone (required, must match format)
    if (empty(trim($data['phone']))) {
        $errors['phone'] = "Phone number is required";
    } elseif (!preg_match("/^[0-9+\-\(\)\s]{6,20}$/", $data['phone'])) {
        $errors['phone'] = "Please enter a valid phone number";
    }
    
    // Validate email (optional, but if provided, must be valid)
    if (!empty(trim($data['email']))) {
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = "Please enter a valid email address";
        }
    }
    
    // Validate address (required, maximum 255 characters)
    if (empty(trim($data['address']))) {
        $errors['address'] = "Address is required";
    } elseif (strlen($data['address']) > 255) {
        $errors['address'] = "Address must not exceed 255 characters";
    }
    
    return $errors;
}

$name = $phone = $email = $address = "";
$name_err = $phone_err = $email_err = $address_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate the input data
    $errors = validateCustomerData($_POST);
    
    if(empty($errors)){
        $sql = "INSERT INTO customers (name, phone, email, address) VALUES (:name, :phone, :email, :address)";
        
        if($stmt = $pdo->prepare($sql)){
            $stmt->bindParam(":name", $param_name);
            $stmt->bindParam(":phone", $param_phone);
            $stmt->bindParam(":email", $param_email);
            $stmt->bindParam(":address", $param_address);
            
            // Set parameters with cleaned data
            $param_name = trim($_POST["name"]);
            $param_phone = trim($_POST["phone"]);
            $param_email = trim($_POST["email"]);
            $param_address = trim($_POST["address"]);
            
            if($stmt->execute()){
                $_SESSION['success_message'] = "Customer added successfully!";
                header("location: customers.php");
                exit();
            } else{
                $_SESSION['error_message'] = "Something went wrong. Please try again later.";
            }
        }
        unset($stmt);
    } else {
        // Assign validation errors to respective error variables
        $name_err = $errors['name'] ?? "";
        $phone_err = $errors['phone'] ?? "";
        $email_err = $errors['email'] ?? "";
        $address_err = $errors['address'] ?? "";
        
        // Store form data in session for repopulating the form
        $_SESSION['form_data'] = $_POST;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Customer - Medical Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="medical.php">Medical Shop</a>
        <div class="navbar-nav ml-auto">
            <a href="customers.php" class="btn btn-primary mr-2">Back to Customers</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        <h4>Add New Customer</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control <?php echo (!empty($name_err)) ? 'is-invalid' : ''; ?>" 
                                       value="<?php echo isset($_SESSION['form_data']['name']) ? htmlspecialchars($_SESSION['form_data']['name']) : $name; ?>">
                                <span class="invalid-feedback"><?php echo $name_err; ?></span>
                            </div>
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="text" name="phone" class="form-control <?php echo (!empty($phone_err)) ? 'is-invalid' : ''; ?>" 
                                       value="<?php echo isset($_SESSION['form_data']['phone']) ? htmlspecialchars($_SESSION['form_data']['phone']) : $phone; ?>">
                                <span class="invalid-feedback"><?php echo $phone_err; ?></span>
                            </div>
                            <div class="form-group">
                                <label>Email (Optional)</label>
                                <input type="email" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" 
                                       value="<?php echo isset($_SESSION['form_data']['email']) ? htmlspecialchars($_SESSION['form_data']['email']) : $email; ?>">
                                <span class="invalid-feedback"><?php echo $email_err; ?></span>
                            </div>
                            <div class="form-group">
                                <label>Address</label>
                                <textarea name="address" class="form-control <?php echo (!empty($address_err)) ? 'is-invalid' : ''; ?>"
                                ><?php echo isset($_SESSION['form_data']['address']) ? htmlspecialchars($_SESSION['form_data']['address']) : $address; ?></textarea>
                                <span class="invalid-feedback"><?php echo $address_err; ?></span>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save Customer</button>
                                <a href="customers.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
// Clean up session variables
if(isset($_SESSION['form_data'])) {
    unset($_SESSION['form_data']);
}
?>