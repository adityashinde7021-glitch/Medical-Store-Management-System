<?php
session_start();
require_once "config.php";

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
	header("location: login.php");
	exit;
}

if (!isset($_GET['order_id'])) {
	header("location: medical.php");
	exit;
}

$order_id = $_GET['order_id'];

// Get order details
$sql = "SELECT o.*, u.full_name, u.email 
		FROM orders o 
		JOIN users u ON o.user_id = u.id 
		WHERE o.id = ? AND o.user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $order_id, $_SESSION['id']);
mysqli_stmt_execute($stmt);
$order = mysqli_stmt_get_result($stmt)->fetch_assoc();

// Get order items
$sql = "SELECT oi.*, m.name 
		FROM order_items oi 
		JOIN medicines m ON oi.medicine_id = m.id 
		WHERE oi.order_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$items = mysqli_stmt_get_result($stmt)->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Invoice - Medical Shop</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<style>
		.invoice-box {
			max-width: 800px;
			margin: auto;
			padding: 30px;
			border: 1px solid #eee;
			box-shadow: 0 0 10px rgba(0, 0, 0, .15);
			font-size: 16px;
			line-height: 24px;
		}
	</style>
</head>
<body>
	<div class="container mt-5">
		<div class="invoice-box">
			<div class="row">
				<div class="col-12">
					<h2>INVOICE</h2>
					<hr>
				</div>
			</div>
			
			<div class="row mb-4">
				<div class="col-6">
					<h6>Bill To:</h6>
					<div><?php echo htmlspecialchars($order['full_name']); ?></div>
					<div><?php echo htmlspecialchars($order['email']); ?></div>
				</div>
				<div class="col-6 text-right">
					<h6>Order Details:</h6>
					<div>Order #: <?php echo $order_id; ?></div>
					<div>Date: <?php echo date('Y-m-d', strtotime($order['order_date'])); ?></div>
				</div>
			</div>

			<div class="row">
				<div class="col-12">
					<table class="table">
						<thead>
							<tr>
								<th>Item</th>
								<th>Quantity</th>
								<th>Price</th>
								<th>Total</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($items as $item): ?>
							<tr>
								<td><?php echo htmlspecialchars($item['name']); ?></td>
								<td><?php echo $item['quantity']; ?></td>
								<td><span class="currency"><?php echo number_format($item['price_per_unit'], 2); ?></span></td>
								<td><span class="currency"><?php echo number_format($item['quantity'] * $item['price_per_unit'], 2); ?></span></td>
							</tr>
							<?php endforeach; ?>
						</tbody>
						<tfoot>
							<tr>
								<td colspan="3" class="text-right"><strong>Total:</strong></td>
								<td><strong><span class="currency"><?php echo number_format($order['total_amount'], 2); ?></span></strong></td>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>

			<div class="row mt-4">
				<div class="col-12 text-center">
					<a href="payment.php?order_id=<?php echo $order_id; ?>" class="btn btn-primary">Proceed to Payment</a>
					<button onclick="window.print()" class="btn btn-secondary">Print Invoice</button>
				</div>
			</div>
		</div>
	</div>
</body>
</html>