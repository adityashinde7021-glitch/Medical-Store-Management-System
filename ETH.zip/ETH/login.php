<?php
session_start();
require_once "config.php";

// Check if user is already logged in
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
	header("location: medical.php");
	exit;
}

$username = $password = "";
$username_err = $password_err = $login_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
	// Verify CSRF token
	if (!isset($_POST['csrf_token']) || !verify_csrf_token($_POST['csrf_token'])) {
		$login_err = "Invalid request";
		log_activity(0, 'login_failed', 'CSRF validation failed');
		goto render_page;
	}

	// Check rate limiting
	if (!check_rate_limit('login', MAX_LOGIN_ATTEMPTS, LOGIN_TIMEOUT)) {
		$login_err = "Too many failed attempts. Please try again after " . (LOGIN_TIMEOUT/60) . " minutes.";
		log_activity(0, 'login_blocked', 'Rate limit exceeded');
		goto render_page;
	}

	// Validate username
	$username = clean_input($_POST["username"]);
	if(empty($username)){
		$username_err = "Please enter username.";
	}
	
	// Validate password
	$password = $_POST["password"];
	if(empty($password)){
		$password_err = "Please enter your password.";
	}
	
	if(empty($username_err) && empty($password_err)){
		$sql = "SELECT id, username, password, role FROM users WHERE username = :username AND status = 'active'";
		
		try {
			$stmt = $pdo->prepare($sql);
			$stmt->bindParam(":username", $username, PDO::PARAM_STR);
			
			if($stmt->execute()){
				if($stmt->rowCount() == 1){
					$row = $stmt->fetch();
					if(password_verify($password, $row["password"])){
						// Start new session with regenerated ID
						session_regenerate_id(true);
						
						$_SESSION["loggedin"] = true;
						$_SESSION["id"] = $row["id"];
						$_SESSION["username"] = $row["username"];
						$_SESSION["role"] = $row["role"];
						$_SESSION["last_activity"] = time();
						
						// Update last login time
						$update_sql = "UPDATE users SET last_login = NOW() WHERE id = ?";
						$pdo->prepare($update_sql)->execute([$row["id"]]);
						
						log_activity($row["id"], 'login_success', 'User logged in successfully');
						
						header("location: medical.php");
						exit;
					} else {
						$login_err = "Invalid username or password.";
						log_activity(0, 'login_failed', 'Invalid password for user: ' . $username);
					}
				} else {
					$login_err = "Invalid username or password.";
					log_activity(0, 'login_failed', 'Invalid username: ' . $username);
				}
			}
		} catch(PDOException $e) {
			error_log("Login error: " . $e->getMessage());
			$login_err = "Something went wrong. Please try again later.";
		}
	}
}

render_page:

?>

<!DOCTYPE html>
<html>
<head>
	<title>Login - Medical Shop</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				<div class="card">
					<div class="card-header">
						<h3 class="text-center">Login</h3>
					</div>
					<div class="card-body">
						<?php 
						if(!empty($login_err)){
							echo '<div class="alert alert-danger">' . $login_err . '</div>';
						}        
						?>
						<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
							<input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo htmlspecialchars($username); ?>">
                                <span class="invalid-feedback"><?php echo htmlspecialchars($username_err); ?></span>
                            </div>    
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                                <span class="invalid-feedback"><?php echo htmlspecialchars($password_err); ?></span>
                            </div>
							<div class="form-group">
								<input type="submit" class="btn btn-primary btn-block" value="Login">
							</div>
							<p class="text-center">Don't have an account? <a href="register.php">Sign up now</a>.</p>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>    
</body>
</html>