<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
	header("location: login.php");
	exit;
}

// Fetch low stock items
$low_stock_items = [];
try {
	$sql = "SELECT name, quantity FROM medicines WHERE quantity <= 10 ORDER BY quantity ASC LIMIT 5";
	$stmt = $pdo->prepare($sql);
	$stmt->execute();
	$low_stock_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
	error_log("Error fetching low stock items: " . $e->getMessage());
}

// Get total items in stock
$total_items = 0;
try {
	$sql = "SELECT COUNT(*) as total FROM medicines WHERE quantity > 0";
	$stmt = $pdo->prepare($sql);
	$stmt->execute();
	$result = $stmt->fetch(PDO::FETCH_ASSOC);
	$total_items = $result['total'];
} catch(PDOException $e) {
	error_log("Error fetching total items: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Medical Shop Dashboard</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/medical-style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<style>
		.currency::before {
			content: '₹';
		}
        .stock-alert {
            color: #dc3545;
            font-weight: bold;
        }
        .stock-warning {
            color: #ffc107;
            font-weight: bold;
        }
        .stock-card {
            background-color: #f8f9fa;
            border-left: 4px solid #28a745;
        }
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="#">Medical Shop</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a class="nav-link" href="medicines.php">Medicines</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="order.php">Orders</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="suppliers.php">Suppliers</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="customers.php">Customers</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="reports.php">Reports</a>
				</li>
			</ul>
			<div class="navbar-nav">
				<span class="navbar-text mr-3">
					Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>
				</span>
				<a href="logout.php" class="btn btn-danger">Logout</a>
			</div>
		</div>
	</nav>

	<div class="container mt-5">
		<h2>Welcome to Medical Shop Management System</h2>
		<div class="row mt-4">
            <!-- Stock Management Card -->
            <div class="col-md-4">
                <div class="card stock-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-boxes mr-2"></i>Stock Management</h5>
                        <p class="card-text">Total Items in Stock: <?php echo $total_items; ?></p>
                        <?php if (!empty($low_stock_items)): ?>
                            <div class="mt-2">
                                <h6 class="text-danger">Low Stock Alert:</h6>
                                <ul class="list-unstyled">
                                    <?php foreach($low_stock_items as $item): ?>
                                        <li class="<?php echo $item['quantity'] <= 5 ? 'stock-alert' : 'stock-warning'; ?>">
                                            <?php echo htmlspecialchars($item['name']); ?> 
                                            (<?php echo $item['quantity']; ?> left)
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <a href="stock_management.php" class="btn btn-primary">Manage Stock</a>
                    </div>
                </div>
            </div>
			<div class="col-md-4">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Medicines</h5>
						<p class="card-text">View and manage medicine inventory</p>
						<a href="medicines.php" class="btn btn-primary">Manage Medicines</a>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Profile</h5>
						<p class="card-text">Update your profile information</p>
						<a href="profile.php" class="btn btn-primary">View Profile</a>
					</div>
				</div>
			</div>
			<div class="col-md-4 mt-4">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Suppliers</h5>
						<p class="card-text">Manage medicine suppliers</p>
						<a href="suppliers.php" class="btn btn-primary">Manage Suppliers</a>
					</div>
				</div>
			</div>
			<div class="col-md-4 mt-4">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Reports</h5>
						<p class="card-text">View sales and inventory reports</p>
						<a href="reports.php" class="btn btn-primary">View Reports</a>
					</div>
				</div>
			</div>
			<div class="col-md-4 mt-4">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Customers</h5>
						<p class="card-text">Manage customer information</p>
						<a href="customers.php" class="btn btn-primary">Manage Customers</a>
					</div>
				</div>
			</div>
			<div class="col-md-4 mt-4">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Order</h5>
						<p class="card-text">Manage orders</p>
						<a href="order.php" class="btn btn-primary">Manage Orders</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>