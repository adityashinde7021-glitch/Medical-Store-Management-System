<?php
session_start();
require_once "config.php";

// Validation functions
function validateSupplierData($data) {
    $errors = [];
    
    // Validate name (required, 2-100 characters)
    if (empty(trim($data['name']))) {
        $errors['name'] = "Supplier name is required";
    } elseif (strlen($data['name']) < 2 || strlen($data['name']) > 100) {
        $errors['name'] = "Name must be between 2 and 100 characters";
    }
    
    // Validate contact person (optional, but if provided, 2-100 characters)
    if (!empty(trim($data['contact_person'])) && (strlen($data['contact_person']) < 2 || strlen($data['contact_person']) > 100)) {
        $errors['contact_person'] = "Contact person name must be between 2 and 100 characters";
    }
    
    // Validate phone (optional, but if provided, must be valid format)
    if (!empty(trim($data['phone']))) {
        if (!preg_match("/^[0-9+\-\(\)\s]{6,20}$/", $data['phone'])) {
            $errors['phone'] = "Please enter a valid phone number";
        }
    }
    
    // Validate email (optional, but if provided, must be valid format)
    if (!empty(trim($data['email']))) {
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = "Please enter a valid email address";
        }
    }
    
    // Validate address (optional, but if provided, maximum 255 characters)
    if (!empty(trim($data['address'])) && strlen($data['address']) > 255) {
        $errors['address'] = "Address must not exceed 255 characters";
    }
    
    return $errors;
}

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Process form submission for adding/editing supplier
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $errors = validateSupplierData($_POST);
        
        if (empty($errors)) {
            if ($_POST['action'] == 'add') {
                $sql = "INSERT INTO suppliers (name, contact_person, phone, email, address) VALUES (?, ?, ?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    trim($_POST['name']),
                    trim($_POST['contact_person']),
                    trim($_POST['phone']),
                    trim($_POST['email']),
                    trim($_POST['address'])
                ]);
                $_SESSION['success_message'] = "Supplier added successfully!";
            } elseif ($_POST['action'] == 'edit') {
                $sql = "UPDATE suppliers SET name=?, contact_person=?, phone=?, email=?, address=? WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    trim($_POST['name']),
                    trim($_POST['contact_person']),
                    trim($_POST['phone']),
                    trim($_POST['email']),
                    trim($_POST['address']),
                    $_POST['id']
                ]);
                $_SESSION['success_message'] = "Supplier updated successfully!";
            }
            header("location: suppliers.php");
            exit;
        } else {
            $_SESSION['errors'] = $errors;
            $_SESSION['form_data'] = $_POST;
            header("location: suppliers.php");
            exit;
        }
    }
}

// Delete supplier
if (isset($_GET['delete'])) {
    $sql = "DELETE FROM suppliers WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$_GET['delete']]);
    $_SESSION['success_message'] = "Supplier deleted successfully!";
    header("location: suppliers.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Suppliers - Medical Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="medical.php">Medical Shop</a>
        <div class="navbar-nav ml-auto">
            <a href="medical.php" class="btn btn-primary mr-2">Dashboard</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if(isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php 
                echo $_SESSION['success_message'];
                unset($_SESSION['success_message']);
                ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>

        <?php if(isset($_SESSION['errors'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">
                    <?php 
                    foreach($_SESSION['errors'] as $error) {
                        echo "<li>" . htmlspecialchars($error) . "</li>";
                    }
                    unset($_SESSION['errors']);
                    ?>
                </ul>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Manage Suppliers</h2>
            <button class="btn btn-primary" data-toggle="modal" data-target="#addSupplierModal">Add New Supplier</button>
        </div>

        <table id="suppliersTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Contact Person</th>
                    <th>Second Phone no</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM suppliers ORDER BY name";
                $result = $pdo->query($sql);
                while($row = $result->fetch()) {
                    echo "<tr>";
                    echo "<td>".$row['id']."</td>";
                    echo "<td>".$row['name']."</td>";
                    echo "<td>".$row['contact_person']."</td>";
                    echo "<td>".$row['phone']."</td>";
                    echo "<td>".$row['email']."</td>";
                    echo "<td>".$row['address']."</td>";
                    echo "<td>
                            <button class='btn btn-sm btn-primary edit-btn' data-id='".$row['id']."'>Edit</button>
                            <a href='suppliers.php?delete=".$row['id']."' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Add Supplier Modal -->
    <div class="modal fade" id="addSupplierModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add New Supplier</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="suppliers.php" method="post">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control <?php echo isset($_SESSION['errors']['name']) ? 'is-invalid' : ''; ?>" 
                                   value="<?php echo isset($_SESSION['form_data']['name']) ? htmlspecialchars($_SESSION['form_data']['name']) : ''; ?>" required>
                            <?php if(isset($_SESSION['errors']['name'])): ?>
                                <div class="invalid-feedback"><?php echo htmlspecialchars($_SESSION['errors']['name']); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Contact Person </label>
                            <input type="text" name="contact_person" class="form-control <?php echo isset($_SESSION['errors']['contact_person']) ? 'is-invalid' : ''; ?>"
                                   value="<?php echo isset($_SESSION['form_data']['contact_person']) ? htmlspecialchars($_SESSION['form_data']['contact_person']) : ''; ?>">
                            <?php if(isset($_SESSION['errors']['contact_person'])): ?>
                                <div class="invalid-feedback"><?php echo htmlspecialchars($_SESSION['errors']['contact_person']); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Second Phone no</label>
                            <input type="text" name="phone" class="form-control <?php echo isset($_SESSION['errors']['phone']) ? 'is-invalid' : ''; ?>"
                                   value="<?php echo isset($_SESSION['form_data']['phone']) ? htmlspecialchars($_SESSION['form_data']['phone']) : ''; ?>">
                            <?php if(isset($_SESSION['errors']['phone'])): ?>
                                <div class="invalid-feedback"><?php echo htmlspecialchars($_SESSION['errors']['phone']); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control <?php echo isset($_SESSION['errors']['email']) ? 'is-invalid' : ''; ?>"
                                   value="<?php echo isset($_SESSION['form_data']['email']) ? htmlspecialchars($_SESSION['form_data']['email']) : ''; ?>">
                            <?php if(isset($_SESSION['errors']['email'])): ?>
                                <div class="invalid-feedback"><?php echo htmlspecialchars($_SESSION['errors']['email']); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <textarea name="address" class="form-control <?php echo isset($_SESSION['errors']['address']) ? 'is-invalid' : ''; ?>"
                                      ><?php echo isset($_SESSION['form_data']['address']) ? htmlspecialchars($_SESSION['form_data']['address']) : ''; ?></textarea>
                            <?php if(isset($_SESSION['errors']['address'])): ?>
                                <div class="invalid-feedback"><?php echo htmlspecialchars($_SESSION['errors']['address']); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Supplier</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Supplier Modal -->
    <div class="modal fade" id="editSupplierModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Supplier</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="suppliers.php" method="post">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" id="edit_id">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" id="edit_name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Contact Person</label>
                            <input type="text" name="contact_person" id="edit_contact_person" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Second Phone no</label>
                            <input type="text" name="phone" id="edit_phone" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" id="edit_email" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <textarea name="address" id="edit_address" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update Supplier</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#suppliersTable').DataTable();

        // Handle edit button click
        $('.edit-btn').click(function() {
            var id = $(this).data('id');
            $.ajax({
                url: 'get_supplier.php',
                type: 'GET',
                data: {id: id},
                success: function(response) {
                    var supplier = JSON.parse(response);
                    $('#edit_id').val(supplier.id);
                    $('#edit_name').val(supplier.name);
                    $('#edit_contact_person').val(supplier.contact_person);
                    $('#edit_phone').val(supplier.phone);
                    $('#edit_email').val(supplier.email);
                    $('#edit_address').val(supplier.address);
                    $('#editSupplierModal').modal('show');
                }
            });
        });
    });
    </script>
    <?php
    // Clean up session variables
    if(isset($_SESSION['form_data'])) {
        unset($_SESSION['form_data']);
    }
    if(isset($_SESSION['errors'])) {
        unset($_SESSION['errors']);
    }
    ?>
</body>
</html> 