<?php
class Validation {
    private $errors = [];
    
    // Validate required fields
    public function required($value, $field_name) {
        if (empty(trim($value))) {
            $this->errors[$field_name] = ucfirst($field_name) . " is required";
            return false;
        }
        return true;
    }
    
    // Validate email
    public function email($email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->errors['email'] = "Invalid email format";
            return false;
        }
        return true;
    }
    
    // Validate numeric value
    public function numeric($value, $field_name) {
        if (!is_numeric($value)) {
            $this->errors[$field_name] = ucfirst($field_name) . " must be a number";
            return false;
        }
        return true;
    }
    
    // Validate minimum length
    public function minLength($value, $field_name, $min) {
        if (strlen($value) < $min) {
            $this->errors[$field_name] = ucfirst($field_name) . " must be at least " . $min . " characters";
            return false;
        }
        return true;
    }
    
    // Validate maximum length
    public function maxLength($value, $field_name, $max) {
        if (strlen($value) > $max) {
            $this->errors[$field_name] = ucfirst($field_name) . " must not exceed " . $max . " characters";
            return false;
        }
        return true;
    }
    
    // Validate date
    public function date($date, $field_name) {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        if (!$d || $d->format('Y-m-d') !== $date) {
            $this->errors[$field_name] = "Invalid date format. Use YYYY-MM-DD";
            return false;
        }
        return true;
    }
    
    // Validate phone number
    public function phone($phone) {
        if (!preg_match("/^[0-9]{10}$/", $phone)) {
            $this->errors['phone'] = "Invalid phone number format (10 digits required)";
            return false;
        }
        return true;
    }
    
    // Validate price/amount
    public function price($price, $field_name) {
        if (!is_numeric($price) || $price < 0) {
            $this->errors[$field_name] = ucfirst($field_name) . " must be a valid positive number";
            return false;
        }
        return true;
    }
    
    // Validate file upload
    public function file($file, $allowed_types = ['jpg', 'jpeg', 'png'], $max_size = 5242880) {
        if (!isset($file['error']) || is_array($file['error'])) {
            $this->errors['file'] = "Invalid file parameter";
            return false;
        }
        
        // Check file size
        if ($file['size'] > $max_size) {
            $this->errors['file'] = "File size too large (max " . ($max_size/1024/1024) . "MB)";
            return false;
        }
        
        // Check file type
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed_types)) {
            $this->errors['file'] = "Invalid file type. Allowed types: " . implode(', ', $allowed_types);
            return false;
        }
        
        return true;
    }
    
    // Get all errors
    public function getErrors() {
        return $this->errors;
    }
    
    // Check if there are any errors
    public function hasErrors() {
        return !empty($this->errors);
    }
    
    // Clear all errors
    public function clearErrors() {
        $this->errors = [];
    }
}
?> 