<?php
require_once "config.php";

if(isset($_POST['signup'])) {
	$username = mysqli_real_escape_string($conn, $_POST['username']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
	
	// Check if username exists
	$sql = "SELECT id FROM users WHERE username = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "s", $username);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_store_result($stmt);
	
	if(mysqli_stmt_num_rows($stmt) > 0) {
		$signup_err = "Username already taken.";
	} else {
		// Hash the password
		$hashed_password = password_hash($password, PASSWORD_DEFAULT);
		
		// Insert new user
		$sql = "INSERT INTO users (username, password, email, full_name) VALUES (?, ?, ?, ?)";
		if($stmt = mysqli_prepare($conn, $sql)) {
			mysqli_stmt_bind_param($stmt, "ssss", $username, $hashed_password, $email, $full_name);
			
			if(mysqli_stmt_execute($stmt)) {
				header("location: login.php");
			} else {
				$signup_err = "Something went wrong. Please try again later.";
			}
			mysqli_stmt_close($stmt);
		}
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Sign Up - Medical Shop</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<div class="container mt-5">
		<h2>Sign Up</h2>
		<?php 
		if(!empty($signup_err)){
			echo '<div class="alert alert-danger">' . $signup_err . '</div>';
		}        
		?>
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
			<div class="form-group">
				<label>Username</label>
				<input type="text" name="username" class="form-control" required>
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" name="password" class="form-control" required>
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="email" name="email" class="form-control" required>
			</div>
			<div class="form-group">
				<label>Full Name</label>
				<input type="text" name="full_name" class="form-control" required>
			</div>
			<div class="form-group">
				<input type="submit" name="signup" class="btn btn-primary" value="Sign Up">
			</div>
			<p>Already have an account? <a href="login.php">Login here</a>.</p>
		</form>
	</div>
</body>
</html>