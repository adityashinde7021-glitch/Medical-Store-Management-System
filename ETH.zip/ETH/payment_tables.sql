-- Create orders table if not exists
CREATE TABLE IF NOT EXISTS orders (
	order_id INT PRIMARY KEY AUTO_INCREMENT,
	customer_name VARCHAR(100) NOT NULL,
	total_amount DECIMAL(10,2) NOT NULL,
	subtotal DECIMAL(10,2) NOT NULL,
	tax DECIMAL(10,2) NOT NULL,
	status ENUM('Pending', 'Processing', 'Completed', 'Cancelled') DEFAULT 'Pending',
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create payments table if not exists
CREATE TABLE IF NOT EXISTS payments (
	payment_id INT PRIMARY KEY AUTO_INCREMENT,
	order_id INT NOT NULL,
	amount DECIMAL(10,2) NOT NULL,
	payment_method ENUM('qr_code', 'upi', 'credit_card') NOT NULL,
	payment_status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
	payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	image_path VARCHAR(255),
	updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- Create payment_logs table if not exists
CREATE TABLE IF NOT EXISTS payment_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    payment_id INT,
    status VARCHAR(50),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(payment_id)
);

-- Create order_items table if not exists
CREATE TABLE IF NOT EXISTS order_items (
	item_id INT PRIMARY KEY AUTO_INCREMENT,
	order_id INT NOT NULL,
	product_name VARCHAR(100) NOT NULL,
	quantity INT NOT NULL,
	price DECIMAL(10,2) NOT NULL,
	amount DECIMAL(10,2) NOT NULL,
	tax DECIMAL(10,2) NOT NULL,
	FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- Insert sample data for testing
INSERT INTO orders (customer_name, total_amount, subtotal, tax, status) VALUES
('John Doe', 1500.00, 1400.00, 100.00, 'Pending'),
('Jane Smith', 2500.00, 2300.00, 200.00, 'Completed');

-- Add indexes for better performance
CREATE INDEX idx_order_status ON orders(status);
CREATE INDEX idx_payment_status ON payments(payment_status);
CREATE INDEX idx_payment_method ON payments(payment_method);