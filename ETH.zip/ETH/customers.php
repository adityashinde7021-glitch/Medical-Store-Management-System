<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Customers - Medical Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="medical.php">Medical Shop</a>
        <div class="navbar-nav ml-auto">
            <a href="medical.php" class="btn btn-primary mr-2">Dashboard</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>Customers Management</h2>
                    <a href="add_customer.php" class="btn btn-success"><i class="fas fa-plus"></i> Add New Customer</a>
                </div>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Address</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM customers ORDER BY name";
                                if($stmt = $pdo->prepare($sql)){
                                    if($stmt->execute()){
                                        while($row = $stmt->fetch()){
                                            echo "<tr>";
                                            echo "<td>" . $row['id'] . "</td>";
                                            echo "<td>" . $row['name'] . "</td>";
                                            echo "<td>" . $row['phone'] . "</td>";
                                            echo "<td>" . $row['email'] . "</td>";
                                            echo "<td>" . $row['address'] . "</td>";
                                            echo "<td>";
                                            echo "<a href='edit_customer.php?id=". $row['id'] ."' class='btn btn-primary btn-sm mr-1'><i class='fas fa-edit'></i></a>";
                                            echo "<a href='delete_customer.php?id=". $row['id'] ."' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'><i class='fas fa-trash'></i></a>";
                                            echo "</td>";
                                            echo "</tr>";
                                        }
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Adding Related Pages Section -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Related Pages</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 mb-2">
                                <a href="medicines.php" class="btn btn-info btn-block">
                                    <i class="fas fa-pills mr-2"></i>Medicines
                                </a>
                            </div>
                            <div class="col-md-3 mb-2">
                                <a href="suppliers.php" class="btn btn-info btn-block">
                                    <i class="fas fa-truck mr-2"></i>Suppliers
                                </a>
                            </div>
                            <div class="col-md-3 mb-2">
                                <a href="invoice.php" class="btn btn-info btn-block">
                                    <i class="fas fa-file-invoice mr-2"></i>Invoices
                                </a>
                            </div>
                            <div class="col-md-3 mb-2">
                                <a href="payment.php" class="btn btn-info btn-block">
                                    <i class="fas fa-money-bill-wave mr-2"></i>Payments
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 