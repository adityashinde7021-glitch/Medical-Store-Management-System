<?php
require_once "config.php";

try {
    // Add customer_name column
    $sql = "ALTER TABLE orders 
            ADD COLUMN IF NOT EXISTS customer_name VARCHAR(255) AFTER order_id,
            ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50) AFTER total_amount,
            ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP";
    
    $pdo->exec($sql);
    echo "Table updated successfully";
} catch(PDOException $e) {
    echo "Error updating table: " . $e->getMessage();
}
?> 