<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Check if user has permission to edit medicines
$stmt = $pdo->prepare("
    SELECT r.name as role
    FROM users u
    JOIN user_roles ur ON u.id = ur.user_id
    JOIN roles r ON ur.role_id = r.id
    WHERE u.id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$userRoles = $stmt->fetchAll(PDO::FETCH_COLUMN);

if (!in_array('admin', $userRoles) && !in_array('pharmacist', $userRoles)) {
    $_SESSION['error'] = "You don't have permission to edit medicines";
    header('Location: medicines.php');
    exit();
}

// Get medicine ID from URL
$medicine_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$medicine_id) {
    header('Location: medicines.php');
    exit();
}

// At the top of the file after session_start()
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF token validation failed');
    }
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = filter_var($_POST['price'], FILTER_VALIDATE_FLOAT);
    $quantity = filter_var($_POST['quantity'], FILTER_VALIDATE_INT);
    $category_id = filter_var($_POST['category_id'], FILTER_VALIDATE_INT);
    $supplier_id = filter_var($_POST['supplier_id'], FILTER_VALIDATE_INT);
    $expiry_date = trim($_POST['expiry_date']);
    $batch_number = trim($_POST['batch_number']);

    $errors = [];

    // Enhanced validation
    if (empty($name) || strlen($name) > 100) {
        $errors[] = "Medicine name is required and must be less than 100 characters";
    }
    if ($price === false || $price <= 0) {
        $errors[] = "Please enter a valid price greater than 0";
    }
    if ($quantity === false || $quantity < 0) {
        $errors[] = "Please enter a valid quantity (0 or greater)";
    }
    if (!empty($expiry_date) && !strtotime($expiry_date)) {
        $errors[] = "Please enter a valid expiry date";
    }
    if (empty($category_id)) {
        $errors[] = "Please select a category";
    }
    if (empty($supplier_id)) {
        $errors[] = "Please select a supplier";
    }
    if (!empty($batch_number) && strlen($batch_number) > 50) {
        $errors[] = "Batch number must be less than 50 characters";
    }

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                UPDATE medicines 
                SET name = ?, description = ?, price = ?, quantity = ?, 
                    category_id = ?, supplier_id = ?, expiry_date = ?, 
                    batch_number = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $name, $description, $price, $quantity, 
                $category_id, $supplier_id, $expiry_date, 
                $batch_number, $medicine_id
            ]);

            // Log the update in audit_logs
            $stmt = $pdo->prepare("
                INSERT INTO audit_logs (user_id, action, table_name, record_id, changes)
                VALUES (?, 'update', 'medicines', ?, ?)
            ");
            $changes = json_encode($_POST);
            $stmt->execute([$_SESSION['user_id'], $medicine_id, $changes]);

            $_SESSION['success'] = "Medicine updated successfully";
            header('Location: medicines.php');
            exit();
        } catch (PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

// Fetch medicine details
try {
    $stmt = $pdo->prepare("
        SELECT m.*, c.name as category_name, s.name as supplier_name
        FROM medicines m
        LEFT JOIN medicine_categories c ON m.category_id = c.id
        LEFT JOIN suppliers s ON m.supplier_id = s.id
        WHERE m.id = ?
    ");
    $stmt->execute([$medicine_id]);
    $medicine = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$medicine) {
        $_SESSION['error'] = "Medicine not found";
        header('Location: medicines.php');
        exit();
    }

    // Fetch all categories
    $stmt = $pdo->query("SELECT id, name FROM medicine_categories");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch all suppliers
    $stmt = $pdo->query("SELECT id, name FROM suppliers");
    $suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $_SESSION['error'] = "Database error: " . $e->getMessage();
    header('Location: medicines.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Medicine - Medical Shop</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/edit_medicine.js"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container">
        <h1>Edit Medicine</h1>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" class="form-container">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="form-group">
                <label for="name">Medicine Name:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($medicine['name']); ?>" required>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea id="description" name="description"><?php echo htmlspecialchars($medicine['description']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" id="price" name="price" step="0.01" value="<?php echo htmlspecialchars($medicine['price']); ?>" required>
            </div>

            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" value="<?php echo htmlspecialchars($medicine['quantity']); ?>" required>
            </div>

            <div class="form-group">
                <label for="category_id">Category:</label>
                <select id="category_id" name="category_id">
                    <option value="">Select Category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>" 
                            <?php echo ($medicine['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="supplier_id">Supplier:</label>
                <select id="supplier_id" name="supplier_id">
                    <option value="">Select Supplier</option>
                    <?php foreach ($suppliers as $supplier): ?>
                        <option value="<?php echo $supplier['id']; ?>"
                            <?php echo ($medicine['supplier_id'] == $supplier['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($supplier['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="expiry_date">Expiry Date:</label>
                <input type="date" id="expiry_date" name="expiry_date" 
                    value="<?php echo htmlspecialchars($medicine['expiry_date']); ?>">
            </div>

            <div class="form-group">
                <label for="batch_number">Batch Number:</label>
                <input type="text" id="batch_number" name="batch_number" 
                    value="<?php echo htmlspecialchars($medicine['batch_number']); ?>">
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Update Medicine</button>
                <a href="medicines.php" class="btn btn-secondary">Cancel</a>
                
                <?php if (in_array('admin', $userRoles)): ?>
                    <button type="button" class="btn btn-danger" onclick="confirmDelete()">Delete Medicine</button>
                <?php endif; ?>
            </div>
        </form>

        <form id="deleteForm" action="delete_medicine.php" method="POST" style="display: none;">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="medicine_id" value="<?php echo $medicine_id; ?>">
            <input type="hidden" name="mark_inactive" id="mark_inactive" value="0">
        </form>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html> 