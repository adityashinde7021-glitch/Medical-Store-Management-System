CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    product_code VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) DEFAULT 0.00
);

-- Insert product data
INSERT INTO products (product_name, product_code) VALUES
    ('Adrino', 'Adrino-100gm'),
    ('Adviser', 'Adviser-250ml'),
    ('AGIL', 'AGIL-100ML'),
    ('AGIL', 'AGIL-250ML'),
    ('Agri82', 'Agri82-500ml'),
    ('Agri82', 'Agri82-100ml'),
    ('Agri82', 'Agri82-5Ltr'),
    ('05.30-15', '05.30-15-1kg'),
    ('Aliette', 'Aliette-100gm'),
    ('Aliette', 'Aliette-250gm'),
    ('Aliette', 'Aliette-500gm'),
    ('Alika', 'Alika-40ml'),
    ('Alika', 'Alika-80ml'),
    ('Altrataf', 'Altrataf-500gm'),
    ('AMBITION', 'AMBITION-500ML'),
    ('Ami-mix', 'Ami-mix-250gm'),
    ('Amino', 'Amino-500ml'),
    ('Amino-sil', 'Amino-sil-250gm'),
    ('Amistar', 'Amistar-200ml'),
    ('AmistarTop', 'AmistarTop-200ml'),
    ('Amoxil', 'Amoxil-100ml'),
    ('Ampligo', 'Ampligo-25ml'),
    ('Ampligo', 'Ampligo-80ml'),
    ('Amrutfert', 'Amrutfert-1ltr'),
    ('Amrutfert', 'Amrutfert-5Ltr'),
    ('Antracol', 'Antracol-1kg'),
    ('Glyphosate', 'Glyphosate (e.g., Roundup)'),
    ('2,4-D', '2,4-D (e.g., Weed B Gon)'),
    ('Atrazine', 'Atrazine (e.g., Aatrex)'),
    ('Dicamba', 'Dicamba (e.g., Banvel)');

-- Add indexes for better performance
CREATE INDEX idx_product_code ON products(product_code);
CREATE INDEX idx_product_name ON products(product_name); 