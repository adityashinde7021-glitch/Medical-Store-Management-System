<?php
require_once "config.php";

try {
    // Drop existing orders table if it exists
    $pdo->exec("DROP TABLE IF EXISTS orders");
    
    // Create orders table
    $sql = "CREATE TABLE IF NOT EXISTS orders (
        order_id INT PRIMARY KEY AUTO_INCREMENT,
        customer_name VARCHAR(255),
        total_amount DECIMAL(10,2),
        payment_method VARCHAR(50),
        status VARCHAR(50) DEFAULT 'Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    
    // Insert some sample data
    $sql = "INSERT INTO orders (customer_name, total_amount, payment_method, status) VALUES 
        ('John Doe', 150.00, 'credit', 'Completed'),
        ('Jane Smith', 200.00, 'qr', 'Pending')";
    
    $pdo->exec($sql);
    
    echo "Database setup completed successfully!";
    
} catch(PDOException $e) {
    die("Error setting up database: " . $e->getMessage());
}
?> 