<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Screenshot Upload</title>
    <style>
        .invalid-feedback {
            display: none;
            color: #dc3545;
            font-size: 0.875em;
            margin-top: 0.25rem;
        }
        
        .is-invalid {
            border-color: #dc3545 !important;
        }
        
        .is-invalid ~ .invalid-feedback {
            display: block;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .upload-container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }

        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 25px;
        }

        .upload-area {
            border: 2px dashed #ccc;
            padding: 20px;
            text-align: center;
            border-radius: 5px;
            margin-bottom: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .upload-area:hover {
            border-color: #007bff;
            background-color: #f8f9fa;
        }

        .upload-area i {
            font-size: 48px;
            color: #007bff;
            margin-bottom: 10px;
        }

        #fileInput {
            display: none;
        }

        .upload-btn {
            background-color: #007bff;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .upload-btn:hover {
            background-color: #0056b3;
        }

        #preview {
            margin-top: 20px;
            max-width: 100%;
            display: none;
        }

        .success-message {
            color: #28a745;
            text-align: center;
            margin-top: 10px;
            display: none;
            padding: 10px;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
        }

        .error-message {
            color: #dc3545;
            text-align: center;
            margin-top: 10px;
            display: none;
            padding: 10px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
        }

        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <h2>Upload Screenshot</h2>
        <?php 
        session_start();
        
        // Display validation errors if any
        if(isset($_SESSION['validation_errors'])): ?>
            <div class="alert alert-danger">
                <ul style="margin-bottom: 0;">
                    <?php 
                    foreach($_SESSION['validation_errors'] as $error) {
                        echo "<li>" . htmlspecialchars($error) . "</li>";
                    }
                    unset($_SESSION['validation_errors']);
                    ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(isset($_SESSION['upload_success'])): ?>
            <div class="success-message" style="display: block;">
                <?php 
                    echo $_SESSION['upload_success'];
                    unset($_SESSION['upload_success']);
                ?>
            </div>
        <?php endif; ?>
        <form action="upload_screenshot.php" method="POST" enctype="multipart/form-data" id="uploadForm" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="user_name">Your Name:</label>
                <input type="text" id="user_name" name="user_name" class="form-control" 
                       value="<?php echo isset($_SESSION['form_data']['user_name']) ? htmlspecialchars($_SESSION['form_data']['user_name']) : ''; ?>"
                       pattern="[A-Za-z\s]{2,50}" title="Name should only contain letters and spaces, between 2 and 50 characters" required>
                <div class="invalid-feedback">Please enter a valid name (2-50 characters, letters and spaces only)</div>
            </div>
            <div class="form-group">
                <label for="user_email">Your Email:</label>
                <input type="email" id="user_email" name="user_email" class="form-control"
                       value="<?php echo isset($_SESSION['form_data']['user_email']) ? htmlspecialchars($_SESSION['form_data']['user_email']) : ''; ?>" required>
                <div class="invalid-feedback">Please enter a valid email address</div>
            </div>
            <div class="form-group">
                <label for="user_phone">Phone Number:</label>
                <input type="tel" id="user_phone" name="user_phone" class="form-control"
                       value="<?php echo isset($_SESSION['form_data']['user_phone']) ? htmlspecialchars($_SESSION['form_data']['user_phone']) : ''; ?>"
                       pattern="[0-9+\-\(\)\s]{10,20}" title="Please enter a valid phone number" required>
                <div class="invalid-feedback">Please enter a valid phone number (10-20 digits)</div>
            </div>
            <div class="form-group">
                <label for="transaction_id">Transaction ID (if any):</label>
                <input type="text" id="transaction_id" name="transaction_id" class="form-control"
                       value="<?php echo isset($_SESSION['form_data']['transaction_id']) ? htmlspecialchars($_SESSION['form_data']['transaction_id']) : ''; ?>"
                       pattern="[A-Za-z0-9\-_]{0,50}" title="Transaction ID can contain letters, numbers, hyphens and underscores">
                <div class="invalid-feedback">Transaction ID can only contain letters, numbers, hyphens and underscores</div>
            </div>
            <div class="upload-area" onclick="document.getElementById('fileInput').click()">
                <i class="fas fa-cloud-upload-alt"></i>
                <p>Click or drag and drop to upload screenshot</p>
                <input type="file" id="fileInput" name="screenshot" accept="image/*" onchange="validateAndPreviewImage(this)" required>
                <div class="invalid-feedback">Please select a valid image file (JPG, PNG, or GIF, max 5MB)</div>
            </div>
            <img id="preview" src="#" alt="Preview">
            <button type="submit" class="upload-btn">Upload Screenshot</button>
        </form>
        <div class="success-message">Screenshot uploaded successfully!</div>
        <div class="error-message"></div>
    </div>

    <script src="https://kit.fontawesome.com/your-fontawesome-kit.js"></script>
    <script>
        function validateAndPreviewImage(input) {
            const file = input.files[0];
            const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            const maxSize = 5 * 1024 * 1024; // 5MB
            
            // Reset previous validation
            input.classList.remove('is-invalid');
            
            if (file) {
                if (!allowedTypes.includes(file.type)) {
                    input.classList.add('is-invalid');
                    return false;
                }
                
                if (file.size > maxSize) {
                    input.classList.add('is-invalid');
                    return false;
                }
                
                // Preview valid image
                previewImage(input);
            }
            return true;
        }

        function validateForm() {
            let isValid = true;
            const form = document.getElementById('uploadForm');
            const inputs = form.querySelectorAll('input[required]');
            
            // Reset all validations
            inputs.forEach(input => {
                input.classList.remove('is-invalid');
                if (!input.checkValidity()) {
                    input.classList.add('is-invalid');
                    isValid = false;
                }
            });
            
            // Validate file
            const fileInput = document.getElementById('fileInput');
            if (!validateAndPreviewImage(fileInput)) {
                isValid = false;
            }
            
            return isValid;
        }

        function previewImage(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    var preview = document.getElementById('preview');
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        document.getElementById('uploadForm').onsubmit = function(e) {
            e.preventDefault();
            
            var formData = new FormData(this);
            var errorMessage = document.querySelector('.error-message');
            var successMessage = document.querySelector('.success-message');
            
            // Hide any existing messages
            errorMessage.style.display = 'none';
            successMessage.style.display = 'none';
            
            fetch('upload_screenshot.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if(data.success) {
                    successMessage.style.display = 'block';
                    
                    // Try to update parent window if it exists and has the required elements
                    try {
                        if (window.opener && !window.opener.closed) {
                            const recentPaymentsTable = window.opener.document.querySelector('table tbody');
                            if (recentPaymentsTable && data.recent_payments) {
                                recentPaymentsTable.innerHTML = data.recent_payments;
                                // Force a redraw in case the table doesn't update immediately
                                recentPaymentsTable.style.display = 'none';
                                recentPaymentsTable.offsetHeight; // Force a reflow
                                recentPaymentsTable.style.display = '';
                            }
                        }
                    } catch (err) {
                        console.log('Could not update parent window:', err);
                    }

                    // Redirect after successful upload
                    setTimeout(function() {
                        successMessage.style.display = 'none';
                        if (window.opener && !window.opener.closed) {
                            window.close(); // Close this window if opened as popup
                        } else {
                            window.location.href = 'payment.php'; // Fallback redirect
                        }
                    }, 2000);
                } else {
                    errorMessage.textContent = data.message || 'Upload failed';
                    errorMessage.style.display = 'block';
                }
            })
            .catch(error => {
                errorMessage.textContent = 'An error occurred during upload. Please try again.';
                errorMessage.style.display = 'block';
                console.error('Upload error:', error);
            });
        };
    </script>
    <?php
    // Clean up session form data
    if(isset($_SESSION['form_data'])) {
        unset($_SESSION['form_data']);
    }
    ?>
</body>
</html>
