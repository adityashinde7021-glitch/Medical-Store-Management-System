<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Shop Invoice</title>
     <!-- CSS styles for the page layout and appearance -->
     <style>
        /* Global styling for the page */
        body {
            background-color: #f8f9fa;
            color: #333;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            padding: 20px;
        }

        /* Heading style */
        h1, h2, p {
            text-align: center;
            color: #2c3e50;
        }

        h2 {
            font-size: 2.5em;
            margin-bottom: 5px;
            color: #2c3e50;
        }

        /* Form styling */
        form {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            max-width: 800px;
            margin: 20px auto;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #34495e;
        }

        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        input:focus, select:focus {
            border-color: #4CAF50;
            outline: none;
            box-shadow: 0 0 5px rgba(76, 175, 80, 0.2);
        }

        /* Button styling */
        button {
            background-color: #4CAF50;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Table styling */
        table {
            width: 100%;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            margin: 20px 0;
            overflow: hidden;
        }

        th {
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            text-align: left;
        }

        td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        /* Summary table styling */
        .table tr:last-child {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
        }

        .table th, .table td {
            padding: 15px;
        }

        /* Print button styling */
        form:last-child {
            text-align: center;
            background: none;
            box-shadow: none;
            padding: 0;
        }

        form:last-child button {
            background-color: #2196F3;
            font-size: 18px;
            padding: 15px 30px;
        }

        form:last-child button:hover {
            background-color: #1976D2;
        }

        /* Responsive design */
        @media screen and (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            form {
                padding: 15px;
            }
            
            table {
                display: block;
                overflow-x: auto;
            }
        }

        /* Add new styles for the menu bar */
        .menu-bar {
            background-color: #4CAF50;
            overflow: hidden;
            margin-bottom: 20px;
        }

        .menu-bar a {
            float: left;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        @media print {
            body * {
                visibility: hidden;
            }
            h2,p {
                visibility: visible;

            }
            #print-table, #print-table * {
                visibility: visible;
            }
            #print-table {
                position: absolute;
                left: 0;
                top: 20%;
            }
        }    
    </style>
</head>
<body>   

    <h2>Medical Care Pharmacy</h2>
    <p>year 2024/25</p><br>
    <div id="content">
         <!-- Heading for the invoice -->
        <h1>Medicine Invoice</h1>
        
        <!-- ... previous code ... -->

         <!-- Form for entering product details -->
    <form class="w-50 mx-auto mt-5 mb-5">
          <!-- ... form input fields ... -->
        <div class="form-group">
            <label for="formGroupExampleInput">Medicine ID</label>
            <input type="number" class="form-control" id="ids" />
        </div>
        <div class="form-group">
            <label for="formGroupExampleInput">Medicine Name</label>
            <select id="product">
                <option value="Paracetamol-500mg">Paracetamol 500mg</option>
                <option value="Amoxicillin-250mg">Amoxicillin 250mg</option>
                <option value="Amoxicillin-500mg">Amoxicillin 500mg</option>
                <option value="Azithromycin-250mg">Azithromycin 250mg</option>
                <option value="Azithromycin-500mg">Azithromycin 500mg</option>
                <option value="Cetirizine-10mg">Cetirizine 10mg</option>
                <option value="Omeprazole-20mg">Omeprazole 20mg</option>
                <option value="Omeprazole-40mg">Omeprazole 40mg</option>
                <option value="Pantoprazole-40mg">Pantoprazole 40mg</option>
                <option value="Metformin-500mg">Metformin 500mg</option>
                <option value="Metformin-1000mg">Metformin 1000mg</option>
                <option value="Amlodipine-5mg">Amlodipine 5mg</option>
                <option value="Amlodipine-10mg">Amlodipine 10mg</option>
                <option value="Aspirin-75mg">Aspirin 75mg</option>
                <option value="Aspirin-150mg">Aspirin 150mg</option>
                <option value="Diclofenac-50mg">Diclofenac 50mg</option>
                <option value="Ibuprofen-400mg">Ibuprofen 400mg</option>
                <option value="Vitamin-B-Complex">Vitamin B Complex</option>
                <option value="Vitamin-C-500mg">Vitamin C 500mg</option>
                <option value="Calcium-500mg">Calcium 500mg</option>
            </select>
        </div>
        <div class="form-group">
            <label for="formGroupExampleInput">Price</label>
            <input type="number" class="form-control" id="prc" />
        </div>
        <div class="form-group">
            <label for="formGroupExampleInput">Quantity</label>
            <input type="number" class="form-control" id="qty" onchange="calculate()" />
        </div>
        <div class="form-group">
            <label for="formGroupExampleInput">Amount</label>
            <input type="number" class="form-control" id="amnt" readonly />
        </div>
        <div class="form-group">
            <label for="tax_rate">Tax Rate (%)</label>
            <input type="number" class="form-control" id="taxrate" step="0.01" min="0" max="100" placeholder="Enter tax rate">
        </div>
        <button type="button" class="btn btn-warning m-2" onclick="adddata()">Add</button>
    </form>
 <!-- Table to display product details -->
    <table id="print-table">
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Amount</th>
                <th>Tax</th>
            </tr>
        </thead>
        <tbody id="newtr"></tbody>
    </table>

        <!-- Table to display subtotal, total tax, and total amount -->
    <table class="table">
        <tr>
            <th width="20">Subtotal:</th>
            <td id="subtotal-amount"></td>
        </tr>
        <tr>
            <th width="20">Total Tax:</th>
            <td id="total-tax"></td>
        </tr>
        <tr>
            <th width="20">Total Amount:</th>
            <td id="total-amount"></td>
        </tr>
    </table>
<!-- ... rest of the code ... -->
<hr><hr>
<!-- Button to trigger printing -->
    <form>
        <button type="button" onclick="handleprint()">Print</button>
        <button type="button" class="btn btn-primary m-2" onclick="proceedToPayment()">Proceed to Payment</button>
    </form>
    <script>
        var price;
        var quantity;
        var amount;
        var prod_name;
        var ids;
        var tax = 0;
        var totalAmount = 0;
        var totalTax = 0;

        function calculate() {
            ids = document.getElementById("ids").value;
            price = document.getElementById("prc").value;
            quantity = document.getElementById("qty").value;
            amount = price * quantity;
            document.getElementById("amnt").value = amount;
            
            // Calculate tax based on tax rate
            var taxRate = parseFloat(document.getElementById("taxrate").value) || 0;
            tax = (amount * taxRate) / 100;
        }

        function adddata() {
            prod_name = document.getElementById("product").value;
            totalAmount += amount;
            totalTax += tax;
            
            document.getElementById("newtr").innerHTML += '<tr><td>' + ids + '</td><td>' + prod_name +
                '</td><td>' + price + '</td><td>' + quantity + '</td><td>' + amount + '</td><td>' + tax.toFixed(2) + '</td></tr>';
            
            // Reset form fields
            document.getElementById("ids").value = "";
            document.getElementById("product").value = "";
            document.getElementById("prc").value = "";
            document.getElementById("qty").value = "";
            document.getElementById("amnt").value = "";
            document.getElementById("taxrate").value = "";
            
            // Update totals
            document.getElementById("subtotal-amount").innerHTML = totalAmount.toFixed(2);
            document.getElementById("total-tax").innerHTML = totalTax.toFixed(2);
            document.getElementById("total-amount").innerHTML = (totalAmount + totalTax).toFixed(2);
        }

        // Add event listener for tax rate changes
        document.getElementById("taxrate").addEventListener("change", calculate);

        function handleprint() {
            window.print();
        }

        function proceedToPayment() {
            // Get all rows from the table
            const rows = document.getElementById("newtr").getElementsByTagName("tr");
            if (rows.length === 0) {
                alert("Please add at least one item to the order");
                return;
            }

            const finalAmount = totalAmount + totalTax;
            
            // Create an array of order items
            let orderItems = [];
            for (let row of rows) {
                const cells = row.getElementsByTagName("td");
                orderItems.push({
                    id: cells[0].innerText,
                    name: cells[1].innerText,
                    price: cells[2].innerText,
                    quantity: cells[3].innerText,
                    amount: cells[4].innerText,
                    tax: cells[5].innerText
                });
            }

            // Create a form to post the data
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'payment.php';

            // Add the order details as hidden fields
            const addHiddenField = (name, value) => {
                const field = document.createElement('input');
                field.type = 'hidden';
                field.name = name;
                field.value = value;
                form.appendChild(field);
            };

            // Add all necessary fields
            addHiddenField('total_amount', finalAmount.toFixed(2));
            addHiddenField('subtotal', totalAmount.toFixed(2));
            addHiddenField('tax', totalTax.toFixed(2));
            addHiddenField('items', JSON.stringify(orderItems));

            // Submit the form
            document.body.appendChild(form);
            form.submit();
        }

    </script>
</body>
</html>