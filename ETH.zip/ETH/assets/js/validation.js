class FormValidator {
    constructor(formId) {
        this.form = document.getElementById(formId);
        this.errors = [];
    }
    
    required(value, fieldName) {
        if (!value || value.trim() === '') {
            this.errors.push(`${fieldName} is required`);
            return false;
        }
        return true;
    }
    
    email(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!re.test(email)) {
            this.errors.push('Invalid email format');
            return false;
        }
        return true;
    }
    
    numeric(value, fieldName) {
        if (isNaN(value)) {
            this.errors.push(`${fieldName} must be a number`);
            return false;
        }
        return true;
    }
    
    price(value, fieldName) {
        if (isNaN(value) || parseFloat(value) < 0) {
            this.errors.push(`${fieldName} must be a valid positive number`);
            return false;
        }
        return true;
    }
    
    phone(phone) {
        const re = /^[0-9]{10}$/;
        if (!re.test(phone)) {
            this.errors.push('Invalid phone number format (10 digits required)');
            return false;
        }
        return true;
    }
    
    getErrors() {
        return this.errors;
    }
    
    hasErrors() {
        return this.errors.length > 0;
    }
    
    clearErrors() {
        this.errors = [];
    }
    
    showErrors() {
        alert(this.errors.join('\n'));
    }
} 