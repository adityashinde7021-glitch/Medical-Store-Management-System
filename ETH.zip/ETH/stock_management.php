<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
	header("location: login.php");
	exit;
}

// Handle new medicine creation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_medicine'])) {
	$errors = [];
	
	// Validate medicine name
	$name = trim($_POST['name']);
	if(empty($name)) {
		$errors[] = "Medicine name is required";
	} elseif(strlen($name) > 100) {
		$errors[] = "Medicine name cannot exceed 100 characters";
	}
	
	// Validate category
	$category_id = $_POST['category_id'];
	if(empty($category_id)) {
		$errors[] = "Category is required";
	} else {
		// Verify category exists
		$stmt = $pdo->prepare("SELECT id FROM medicine_categories WHERE id = ?");
		$stmt->execute([$category_id]);
		if(!$stmt->fetch()) {
			$errors[] = "Invalid category selected";
		}
	}
	
	// Validate quantity
	$quantity = $_POST['quantity'];
	if(!is_numeric($quantity) || $quantity < 0) {
		$errors[] = "Quantity must be a positive number";
	}
	
	// Validate notes
	$notes = trim($_POST['notes']);
	if(empty($notes)) {
		$errors[] = "Notes are required";
	} elseif(strlen($notes) > 500) {
		$errors[] = "Notes cannot exceed 500 characters";
	}
	
	// Check if medicine name already exists
	$stmt = $pdo->prepare("SELECT id FROM medicines WHERE name = ?");
	$stmt->execute([$name]);
	if($stmt->fetch()) {
		$errors[] = "A medicine with this name already exists";
	}
	
	if(empty($errors)) {
		try {
			$pdo->beginTransaction();
			
			// Insert new medicine
			$stmt = $pdo->prepare("INSERT INTO medicines (name, category_id, quantity) VALUES (?, ?, ?)");
			$stmt->execute([$name, $category_id, $quantity]);
			
			$medicine_id = $pdo->lastInsertId();
			
			// Log the initial stock
			$stmt = $pdo->prepare("INSERT INTO stock_movements (medicine_id, type, quantity, notes, created_by) VALUES (?, ?, ?, ?, ?)");
			$stmt->execute([$medicine_id, 'initial', $quantity, $notes, $_SESSION['id']]);
			
			$pdo->commit();
			$_SESSION['success_message'] = "New medicine added successfully!";
		} catch(PDOException $e) {
			$pdo->rollBack();
			$_SESSION['error_message'] = "Error adding medicine: " . $e->getMessage();
		}
	} else {
		$_SESSION['error_message'] = implode("<br>", $errors);
	}
	
	header("Location: stock_management.php");
	exit();
}

// Add query to fetch categories for the dropdown
$categories = [];
try {
	$stmt = $pdo->prepare("SELECT id, name FROM medicine_categories ORDER BY name");
	$stmt->execute();
	$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
	$_SESSION['error_message'] = "Error fetching categories: " . $e->getMessage();
}

// Handle stock updates
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_stock'])) {
	$medicine_id = $_POST['medicine_id'];
	$new_quantity = $_POST['quantity'];
	$notes = $_POST['notes'];

	try {
		$pdo->beginTransaction();

		// Get current quantity
		$stmt = $pdo->prepare("SELECT quantity FROM medicines WHERE id = ?");
		$stmt->execute([$medicine_id]);
		$current = $stmt->fetch(PDO::FETCH_ASSOC);
		
		// Update medicine quantity
		$stmt = $pdo->prepare("UPDATE medicines SET quantity = ? WHERE id = ?");
		$stmt->execute([$new_quantity, $medicine_id]);

		// Log the stock movement
		$quantity_change = $new_quantity - $current['quantity'];
		$movement_type = $quantity_change > 0 ? 'adjustment' : 'adjustment';
		
		$stmt = $pdo->prepare("INSERT INTO stock_movements (medicine_id, type, quantity, notes, created_by) VALUES (?, ?, ?, ?, ?)");
		$stmt->execute([$medicine_id, $movement_type, $quantity_change, $notes, $_SESSION['id']]);

		$pdo->commit();
		$_SESSION['success_message'] = "Stock updated successfully!";
	} catch(PDOException $e) {
		$pdo->rollBack();
		$_SESSION['error_message'] = "Error updating stock: " . $e->getMessage();
	}
	
	header("Location: stock_management.php");
	exit();
}

// Fetch all medicines with their stock information
$medicines = [];
try {
	$sql = "SELECT m.*, c.name as category_name, 
			CASE 
				WHEN m.quantity <= 5 THEN 'critical'
				WHEN m.quantity <= 10 THEN 'low'
				ELSE 'normal'
			END as stock_status
			FROM medicines m 
			LEFT JOIN medicine_categories c ON m.category_id = c.id 
			ORDER BY m.quantity ASC";
	$stmt = $pdo->prepare($sql);
	$stmt->execute();
	$medicines = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
	$_SESSION['error_message'] = "Error fetching medicines: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Stock Management - Medical Shop</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<style>
		.stock-critical { color: #dc3545; font-weight: bold; }
		.stock-low { color: #ffc107; font-weight: bold; }
		.stock-normal { color: #28a745; }
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="medical.php">Medical Shop</a>
		<div class="navbar-nav ml-auto">
			<a href="medical.php" class="btn btn-primary mr-2">Dashboard</a>
			<a href="logout.php" class="btn btn-danger">Logout</a>
		</div>
	</nav>

	<div class="container mt-5">
		<?php if(isset($_SESSION['success_message'])): ?>
			<div class="alert alert-success alert-dismissible fade show">
				<?php 
					echo $_SESSION['success_message'];
					unset($_SESSION['success_message']);
				?>
				<button type="button" class="close" data-dismiss="alert">&times;</button>
			</div>
		<?php endif; ?>

		<?php if(isset($_SESSION['error_message'])): ?>
			<div class="alert alert-danger alert-dismissible fade show">
				<?php 
					echo $_SESSION['error_message'];
					unset($_SESSION['error_message']);
				?>
				<button type="button" class="close" data-dismiss="alert">&times;</button>
			</div>
		<?php endif; ?>

		<h2>Stock Management</h2>
		<div class="card mt-4">
			<div class="card-body">
				<button class="btn btn-success mb-3" onclick="openNewMedicineModal()">
					<i class="fas fa-plus"></i> Add New Medicine
				</button>
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Medicine Name</th>
							<th>Category</th>
							<th>Current Stock</th>
							<th>Status</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($medicines as $medicine): ?>
							<tr>
								<td><?php echo htmlspecialchars($medicine['name']); ?></td>
								<td><?php echo htmlspecialchars($medicine['category_name']); ?></td>
								<td class="stock-<?php echo $medicine['stock_status']; ?>">
									<?php echo $medicine['quantity']; ?> units
								</td>
								<td>
									<?php if($medicine['stock_status'] == 'critical'): ?>
										<span class="badge badge-danger">Critical</span>
									<?php elseif($medicine['stock_status'] == 'low'): ?>
										<span class="badge badge-warning">Low</span>
									<?php else: ?>
										<span class="badge badge-success">Normal</span>
									<?php endif; ?>
								</td>
								<td>
									<button class="btn btn-primary btn-sm" 
											onclick="openUpdateModal(<?php echo $medicine['id']; ?>, 
																   '<?php echo htmlspecialchars($medicine['name']); ?>', 
																   <?php echo $medicine['quantity']; ?>)">
										Update Stock
									</button>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<!-- New Medicine Modal -->
	<div class="modal fade" id="newMedicineModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add New Medicine</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<form action="stock_management.php" method="post" id="newMedicineForm" onsubmit="return validateNewMedicineForm()">
					<div class="modal-body">
						<input type="hidden" name="add_medicine" value="1">
						
						<div class="form-group">
							<label>Medicine Name:</label>
							<input type="text" name="name" class="form-control" required maxlength="100">
							<small class="text-muted">Maximum 100 characters</small>
						</div>
						
						<div class="form-group">
							<label>Category:</label>
							<select name="category_id" class="form-control" required>
								<option value="">Select Category</option>
								<?php foreach($categories as $category): ?>
									<option value="<?php echo $category['id']; ?>">
										<?php echo htmlspecialchars($category['name']); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>
						
						<div class="form-group">
							<label>Initial Quantity:</label>
							<input type="number" name="quantity" class="form-control" required min="0" step="1">
						</div>
						
						<div class="form-group">
							<label>Notes:</label>
							<textarea name="notes" class="form-control" rows="3" required maxlength="500"></textarea>
							<small class="text-muted">Maximum 500 characters</small>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-success">Add Medicine</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- Update Stock Modal -->
	<div class="modal fade" id="updateStockModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Update Stock</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<form action="stock_management.php" method="post">
					<div class="modal-body">
						<input type="hidden" name="medicine_id" id="medicine_id">
						<input type="hidden" name="update_stock" value="1">
						
						<div class="form-group">
							<label>Medicine Name:</label>
							<input type="text" id="medicine_name" class="form-control" readonly>
						</div>
						
						<div class="form-group">
							<label>Current Quantity:</label>
							<input type="number" id="current_quantity" class="form-control" readonly>
						</div>
						
						<div class="form-group">
							<label>New Quantity:</label>
							<input type="number" name="quantity" class="form-control" required min="0">
						</div>
						
						<div class="form-group">
							<label>Notes:</label>
							<textarea name="notes" class="form-control" rows="3" required></textarea>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Update Stock</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	
	<script>
	function openNewMedicineModal() {
		$('#newMedicineModal').modal('show');
	}

	function openUpdateModal(id, name, quantity) {
		$('#medicine_id').val(id);
		$('#medicine_name').val(name);
		$('#current_quantity').val(quantity);
		$('#updateStockModal').modal('show');
	}
	function validateNewMedicineForm() {
		const form = document.getElementById('newMedicineForm');
		const name = form.elements['name'].value.trim();
		const category = form.elements['category_id'].value;
		const quantity = form.elements['quantity'].value;
		const notes = form.elements['notes'].value.trim();
		
		let errors = [];
		
		if(name === '') {
			errors.push('Medicine name is required');
		}
		
		if(category === '') {
			errors.push('Please select a category');
		}
		
		if(quantity === '' || parseInt(quantity) < 0) {
			errors.push('Quantity must be a positive number');
		}
		
		if(notes === '') {
			errors.push('Notes are required');
		}
		
		if(errors.length > 0) {
			alert(errors.join('\n'));
			return false;
		}
		
		return true;
	}
	</script>
</body>
</html>