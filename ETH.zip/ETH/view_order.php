<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Check if order ID is provided
if(!isset($_GET["id"]) || empty($_GET["id"])){
    header("location: payment.php");
    exit;
}

$order_id = $_GET["id"];

// Fetch order details
$sql = "SELECT * FROM orders WHERE order_id = ?";
if($stmt = $pdo->prepare($sql)){
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if(!$order){
        header("location: payment.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Order - Medical Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="medical.php">Medical Shop</a>
        <div class="navbar-nav ml-auto">
            <a href="payment.php" class="btn btn-primary mr-2">Back to Orders</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h2>Order Details #<?php echo $order['order_id']; ?></h2>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Customer Name:</strong> <?php echo $order['customer_name']; ?></p>
                        <p><strong>Order Date:</strong> <?php echo $order['created_at']; ?></p>
                        <p><strong>Payment Method:</strong> <?php echo $order['payment_method']; ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Total Amount:</strong> $<?php echo $order['total_amount']; ?></p>
                        <p><strong>Status:</strong> <?php echo $order['status']; ?></p>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="update_order.php?id=<?php echo $order['order_id']; ?>" class="btn btn-primary">Update Order</a>
                    <button type="button" class="btn btn-danger" onclick="confirmDelete(<?php echo $order['order_id']; ?>)">Delete Order</button>
                </div>
            </div>
        </div>
    </div>

    <script>
    function confirmDelete(orderId) {
        if(confirm('Are you sure you want to delete this order?')) {
            window.location.href = 'update_order.php?id=' + orderId + '&action=delete';
        }
    }
    </script>
</body>
</html> 