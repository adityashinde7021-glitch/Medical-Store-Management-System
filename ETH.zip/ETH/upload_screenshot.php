<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
	header('Content-Type: application/json');
	echo json_encode(['success' => false, 'message' => 'User not logged in']);
	exit;
}

function validateInput($data) {
	$errors = [];
	
	// Validate name
	if (empty(trim($data['user_name']))) {
		$errors[] = "Name is required";
	} elseif (!preg_match("/^[A-Za-z\s]{2,50}$/", trim($data['user_name']))) {
		$errors[] = "Name should only contain letters and spaces, between 2 and 50 characters";
	}
	
	// Validate email
	if (empty(trim($data['user_email']))) {
		$errors[] = "Email is required";
	} elseif (!filter_var(trim($data['user_email']), FILTER_VALIDATE_EMAIL)) {
		$errors[] = "Please enter a valid email address";
	}
	
	// Validate phone
	if (empty(trim($data['user_phone']))) {
		$errors[] = "Phone number is required";
	} elseif (!preg_match("/^[0-9+\-\(\)\s]{10,20}$/", trim($data['user_phone']))) {
		$errors[] = "Please enter a valid phone number";
	}
	
	// Validate transaction ID if provided
	if (!empty(trim($data['transaction_id'])) && !preg_match("/^[A-Za-z0-9\-_]{1,50}$/", trim($data['transaction_id']))) {
		$errors[] = "Transaction ID can only contain letters, numbers, hyphens and underscores";
	}
	
	return $errors;
}

// Define upload directory
$upload_dir = 'uploads/screenshots/';

// Create directory if it doesn't exist
if (!file_exists($upload_dir)) {
	mkdir($upload_dir, 0777, true);
}

// Handle file upload
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$validation_errors = validateInput($_POST);
	
	// Store form data in session for repopulating the form
	$_SESSION['form_data'] = $_POST;
	
	if (!empty($validation_errors)) {
		$_SESSION['validation_errors'] = $validation_errors;
		header("Location: screenshot.php");
		exit;
	}
	
	if (!isset($_FILES["screenshot"]) || $_FILES["screenshot"]["error"] !== UPLOAD_ERR_OK) {
		$_SESSION['validation_errors'] = ["Please select a valid image file"];
		header("Location: screenshot.php");
		exit;
	}
	
	$file = $_FILES["screenshot"];
	
	try {

		// Validate file
		$allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
		$max_size = 5 * 1024 * 1024; // 5MB
		
		// Check file type using finfo
		$finfo = finfo_open(FILEINFO_MIME_TYPE);
		$mime_type = finfo_file($finfo, $file["tmp_name"]);
		finfo_close($finfo);
		
		if (!in_array($mime_type, $allowed_types)) {
			throw new Exception('Invalid file type. Only JPG, PNG and GIF are allowed.');
		}

		if ($file['size'] > $max_size) {
			throw new Exception('File too large. Maximum size is 5MB.');
		}

		// Generate unique filename
		$extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
		$new_filename = 'screenshot_' . time() . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
		$upload_path = $upload_dir . $new_filename;

		// Begin transaction
		$pdo->beginTransaction();

		// Move uploaded file
		if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
			throw new Exception('Failed to move uploaded file.');
		}

		// Update payment record if payment_id exists
		if (isset($_SESSION['payment_id'])) {
			$sql = "UPDATE payments SET 
					payment_status = 'pending_verification',
					image_path = ?,
					user_name = ?,
					user_email = ?,
					user_phone = ?,
					transaction_id = ?,
					updated_at = CURRENT_TIMESTAMP 
					WHERE id = ?";
			$stmt = $pdo->prepare($sql);
			$stmt->execute([
				$upload_path, 
				$user_name,
				$user_email,
				$user_phone,
				$transaction_id,
				$_SESSION['payment_id']
			]);

			// Log the upload
			$sql = "INSERT INTO payment_logs (payment_id, status, message, log_data) 
					VALUES (?, 'screenshot_uploaded', ?, ?)";
			$stmt = $pdo->prepare($sql);
			$log_data = json_encode([
				'user_name' => $user_name,
				'user_email' => $user_email,
				'user_phone' => $user_phone,
				'transaction_id' => $transaction_id,
				'filename' => $new_filename
			]);
			$stmt->execute([$_SESSION['payment_id'], "Screenshot uploaded with user details", $log_data]);
		}

		// Get recent payments
		$sql = "SELECT p.*, o.customer_name 
				FROM payments p 
				JOIN orders o ON p.order_id = o.order_id 
				ORDER BY p.payment_date DESC LIMIT 5";
		$stmt = $pdo->prepare($sql);
		$stmt->execute();
		$recent_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

		// Format recent payments HTML
		$recent_payments_html = '';
		foreach ($recent_payments as $payment) {
			$recent_payments_html .= "<tr>";
			$recent_payments_html .= "<td>" . htmlspecialchars($payment['customer_name']) . "</td>";
			$recent_payments_html .= "<td>" . htmlspecialchars($payment['payment_method']) . "</td>";
			$recent_payments_html .= "<td>" . htmlspecialchars($payment['amount']) . "</td>";
			$recent_payments_html .= "<td>" . htmlspecialchars($payment['payment_status']) . "</td>";
			$recent_payments_html .= "<td>" . htmlspecialchars($payment['payment_date']) . "</td>";
			$recent_payments_html .= "</tr>";
		}

		// Commit transaction
		$pdo->commit();

		$_SESSION['upload_success'] = 'Screenshot uploaded successfully. Payment is pending verification.';
		
		header('Content-Type: application/json');
		echo json_encode([
			'success' => true,
			'message' => 'Screenshot uploaded successfully',
			'file_path' => $upload_path,
			'recent_payments' => $recent_payments_html
		]);

	} catch (Exception $e) {
		if (isset($pdo) && $pdo->inTransaction()) {
			$pdo->rollBack();
		}
		
		error_log("Upload error: " . $e->getMessage());
		header('Content-Type: application/json');
		echo json_encode(['success' => false, 'message' => $e->getMessage()]);
	}
} else {
	header('Content-Type: application/json');
	echo json_encode(['success' => false, 'message' => 'No file uploaded']);
}
?>