<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Check if user has permission to delete medicines
$stmt = $pdo->prepare("
    SELECT r.name as role
    FROM users u
    JOIN user_roles ur ON u.id = ur.user_id
    JOIN roles r ON ur.role_id = r.id
    WHERE u.id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$userRoles = $stmt->fetchAll(PDO::FETCH_COLUMN);

if (!in_array('admin', $userRoles)) {
    $_SESSION['error'] = "You don't have permission to delete medicines";
    header('Location: medicines.php');
    exit();
}

// Verify CSRF token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error'] = "Invalid request";
    header('Location: medicines.php');
    exit();
}

// Get medicine ID
$medicine_id = isset($_POST['medicine_id']) ? intval($_POST['medicine_id']) : 0;

if (!$medicine_id) {
    $_SESSION['error'] = "Invalid medicine ID";
    header('Location: medicines.php');
    exit();
}

try {
    // Start transaction
    $pdo->beginTransaction();

    // Check if medicine exists and get its details for logging
    $stmt = $pdo->prepare("SELECT * FROM medicines WHERE id = ?");
    $stmt->execute([$medicine_id]);
    $medicine = $stmt->fetch();

    if (!$medicine) {
        throw new Exception("Medicine not found");
    }

    // Check if medicine is used in any orders
    $stmt = $pdo->prepare("
        SELECT o.order_id, o.customer_name, o.order_date 
        FROM order_items oi 
        JOIN orders o ON oi.order_id = o.order_id 
        WHERE oi.medicine_id = ?
        LIMIT 5
    ");
    $stmt->execute([$medicine_id]);
    $orders = $stmt->fetchAll();

    if (!empty($orders)) {
        $orderInfo = [];
        foreach ($orders as $order) {
            $orderInfo[] = "Order #" . $order['order_id'] . " by " . $order['customer_name'] . 
                          " on " . date('Y-m-d', strtotime($order['order_date']));
        }
        
        $errorMsg = "Cannot delete medicine as it is associated with orders:\n" . 
                   implode("\n", $orderInfo);
        if (count($orders) == 5) {
            $errorMsg .= "\n(and more...)";
        }
        throw new Exception($errorMsg);
    }

    // Instead of deleting, we could mark it as inactive (optional)
    if (isset($_POST['mark_inactive']) && $_POST['mark_inactive'] == 1) {
        $stmt = $pdo->prepare("
            UPDATE medicines 
            SET status = 'inactive', 
                quantity = 0,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        $stmt->execute([$medicine_id]);
        
        // Log the status change
        $stmt = $pdo->prepare("
            INSERT INTO audit_logs (user_id, action, table_name, record_id, changes)
            VALUES (?, 'deactivate', 'medicines', ?, ?)
        ");
        $changes = json_encode(['status' => 'inactive', 'previous_status' => $medicine['status']]);
        $stmt->execute([$_SESSION['user_id'], $medicine_id, $changes]);
        
        $pdo->commit();
        $_SESSION['success'] = "Medicine marked as inactive successfully";
        header('Location: medicines.php');
        exit();
    }

    // If we get here, we can safely delete the medicine
    // Log the deletion in audit_logs
    $stmt = $pdo->prepare("
        INSERT INTO audit_logs (user_id, action, table_name, record_id, changes)
        VALUES (?, 'delete', 'medicines', ?, ?)
    ");
    $changes = json_encode($medicine);
    $stmt->execute([$_SESSION['user_id'], $medicine_id, $changes]);

    // Delete the medicine
    $stmt = $pdo->prepare("DELETE FROM medicines WHERE id = ?");
    $stmt->execute([$medicine_id]);

    // Commit transaction
    $pdo->commit();

    $_SESSION['success'] = "Medicine deleted successfully";
} catch (Exception $e) {
    // Rollback transaction on error
    $pdo->rollBack();
    $_SESSION['error'] = $e->getMessage();
}

header('Location: medicines.php');
exit(); 