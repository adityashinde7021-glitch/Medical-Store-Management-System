<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Check if order ID is provided
if(!isset($_GET["id"]) || empty($_GET["id"])){
    header("location: payment.php");
    exit;
}

$order_id = $_GET["id"];

// Handle delete action
if(isset($_GET["action"]) && $_GET["action"] === "delete"){
    $sql = "DELETE FROM orders WHERE order_id = ?";
    if($stmt = $pdo->prepare($sql)){
        $stmt->execute([$order_id]);
        $_SESSION['success_message'] = "Order deleted successfully!";
        header("location: payment.php");
        exit;
    }
}

// Process form submission
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $customer_name = $_POST["customer_name"];
    $total_amount = $_POST["total_amount"];
    $status = $_POST["status"];
    
    $sql = "UPDATE orders SET customer_name = ?, total_amount = ?, status = ? WHERE order_id = ?";
    if($stmt = $pdo->prepare($sql)){
        $stmt->execute([$customer_name, $total_amount, $status, $order_id]);
        $_SESSION['success_message'] = "Order updated successfully!";
        header("location: payment.php");
        exit;
    }
}

// Fetch order details
$sql = "SELECT * FROM orders WHERE order_id = ?";
if($stmt = $pdo->prepare($sql)){
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if(!$order){
        header("location: payment.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Order - Medical Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="medical.php">Medical Shop</a>
        <div class="navbar-nav ml-auto">
            <a href="payment.php" class="btn btn-primary mr-2">Back to Orders</a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h2>Update Order #<?php echo $order['order_id']; ?></h2>
            </div>
            <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?id=" . $order_id; ?>" method="post">
                    <div class="form-group">
                        <label>Customer Name</label>
                        <input type="text" name="customer_name" class="form-control" value="<?php echo $order['customer_name']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Total Amount</label>
                        <input type="number" name="total_amount" class="form-control" value="<?php echo $order['total_amount']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control" required>
                            <option value="Pending" <?php echo ($order['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                            <option value="Completed" <?php echo ($order['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                            <option value="Cancelled" <?php echo ($order['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Order</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html> 