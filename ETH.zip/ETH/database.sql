-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS medical_shop;
USE medical_shop;

-- Medicine categories first since it's referenced by medicines
CREATE TABLE IF NOT EXISTS medicine_categories (
	id INT PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(100) NOT NULL,
	description TEXT,
	status ENUM('active', 'inactive') DEFAULT 'active',
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Suppliers table before medicines since it's referenced
CREATE TABLE IF NOT EXISTS suppliers (
	id INT PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(100) NOT NULL,
	contact_person VARCHAR(100),
	phone VARCHAR(20),
	email VARCHAR(100),
	address TEXT,
	tax_number VARCHAR(50),
	payment_terms VARCHAR(100),
	status ENUM('active', 'inactive') DEFAULT 'active',
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Users table with enhanced security and profile fields
CREATE TABLE IF NOT EXISTS users (
	id INT PRIMARY KEY AUTO_INCREMENT,
	username VARCHAR(50) NOT NULL UNIQUE,
	password VARCHAR(255) NOT NULL,
	email VARCHAR(100) NOT NULL UNIQUE,
	full_name VARCHAR(100) NOT NULL,
	phone VARCHAR(20),
	role ENUM('admin', 'pharmacist', 'cashier', 'staff') NOT NULL DEFAULT 'staff',
	status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
	last_login DATETIME,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Enhanced medicines table
CREATE TABLE IF NOT EXISTS medicines (
	id INT PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(100) NOT NULL,
	generic_name VARCHAR(100),
	description TEXT,
	price DECIMAL(10,2) NOT NULL,
	cost_price DECIMAL(10,2) NOT NULL,
	quantity INT NOT NULL DEFAULT 0,
	minimum_quantity INT DEFAULT 10,
	manufacturer VARCHAR(100),
	supplier_id INT,
	category_id INT,
	batch_number VARCHAR(50),
	expiry_date DATE,
	status ENUM('active', 'discontinued', 'out_of_stock') DEFAULT 'active',
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	FOREIGN KEY (supplier_id) REFERENCES suppliers(id),
	FOREIGN KEY (category_id) REFERENCES medicine_categories(id),
	prescription_required BOOLEAN DEFAULT FALSE,
	storage_condition VARCHAR(100),
	barcode VARCHAR(50) UNIQUE,
	rack_number VARCHAR(20),
	shelf_number VARCHAR(20)
);

-- Enhanced customers table
CREATE TABLE IF NOT EXISTS customers (
	id INT PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(100) NOT NULL,
	phone VARCHAR(20) NOT NULL,
	email VARCHAR(100),
	address TEXT NOT NULL,
	medical_history TEXT,
	allergies TEXT,
	points INT DEFAULT 0,
	status ENUM('active', 'inactive') DEFAULT 'active',
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	date_of_birth DATE,
	gender ENUM('male', 'female', 'other'),
	emergency_contact VARCHAR(100),
	emergency_phone VARCHAR(20),
	insurance_provider VARCHAR(100),
	insurance_number VARCHAR(50)
);

-- Create orders table with essential fields
CREATE TABLE IF NOT EXISTS orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(100) NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('Pending', 'Completed', 'Cancelled') DEFAULT 'Pending',
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Enhanced payments table
CREATE TABLE IF NOT EXISTS payments (
	id INT PRIMARY KEY AUTO_INCREMENT,
	order_id INT,
	amount DECIMAL(10,2) NOT NULL,
	payment_method ENUM('cash', 'credit_card', 'debit_card', 'online', 'qr_code', 'crypto', 'bank_transfer') NOT NULL,
	payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
	user_name VARCHAR(100),
	user_email VARCHAR(100),
	user_phone VARCHAR(20),
	transaction_id VARCHAR(100),
	qr_reference VARCHAR(100),
	payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	notes TEXT,
	payment_provider VARCHAR(50),
	provider_transaction_id VARCHAR(100),
	payment_currency VARCHAR(10) DEFAULT 'USD',
	exchange_rate DECIMAL(10,6) DEFAULT 1.000000,
	payment_response TEXT,
	payment_metadata JSON,
	refund_status ENUM('none', 'partial', 'full') DEFAULT 'none',
	FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- Enhanced order details
CREATE TABLE IF NOT EXISTS order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    medicine_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (medicine_id) REFERENCES medicines(id)
);

-- Stock movements table for inventory tracking
CREATE TABLE IF NOT EXISTS stock_movements (
	id INT PRIMARY KEY AUTO_INCREMENT,
	medicine_id INT NOT NULL,
	type ENUM('purchase', 'sale', 'adjustment', 'return') NOT NULL,
	quantity INT NOT NULL,
	reference_id INT,
	notes TEXT,
	created_by INT,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	FOREIGN KEY (medicine_id) REFERENCES medicines(id),
	FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Audit trail
CREATE TABLE IF NOT EXISTS audit_logs (
	id INT PRIMARY KEY AUTO_INCREMENT,
	user_id INT,
	action VARCHAR(50) NOT NULL,
	table_name VARCHAR(50) NOT NULL,
	record_id INT,
	changes TEXT,
	ip_address VARCHAR(45),
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Invoices table
CREATE TABLE IF NOT EXISTS invoices (
	id INT PRIMARY KEY AUTO_INCREMENT,
	order_id INT,
	invoice_number VARCHAR(20) UNIQUE NOT NULL,
	invoice_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	payment_id INT,
	FOREIGN KEY (order_id) REFERENCES orders(order_id),
	FOREIGN KEY (payment_id) REFERENCES payments(id)
);

-- Roles table for user management
CREATE TABLE IF NOT EXISTS roles (
	id INT PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(50) NOT NULL UNIQUE,
	description TEXT,
	created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- User roles table for many-to-many relationship
CREATE TABLE IF NOT EXISTS user_roles (
	user_id INT,
	role_id INT,
	PRIMARY KEY (user_id, role_id),
	FOREIGN KEY (user_id) REFERENCES users(id),
	FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, password, email, full_name, role) 
VALUES ('admin', '$2y$10$8K1p/95qfV8j4I9YL.xDz.7Q.kFNZfvZn4EfGtEr1PIkYy3z5FIqi', 'admin@medical.com', 'Administrator', 'admin')
ON DUPLICATE KEY UPDATE id=id;

-- Insert basic medicine categories
INSERT INTO medicine_categories (name, description) VALUES
('Antibiotics', 'Medicines that fight bacterial infections'),
('Pain Relief', 'Medicines for pain management'),
('Vitamins', 'Nutritional supplements'),
('Antacids', 'Medicines for digestive issues')
ON DUPLICATE KEY UPDATE id=id;

-- Insert sample suppliers
INSERT INTO suppliers (name, contact_person, phone, email, address) VALUES
('PharmaCare Ltd', 'John Smith', '1234567890', 'contact@pharmacare.com', '123 Pharma Street, Medical City'),
('MediSupply Co', 'Jane Doe', '0987654321', 'info@medisupply.com', '456 Supply Road, Health Town'),
('HealthCare Products', 'Mike Johnson', '5555555555', 'sales@healthcare.com', '789 Health Avenue, Care City')
ON DUPLICATE KEY UPDATE id=id;

-- Insert sample medicines
INSERT INTO medicines (name, description, price, cost_price, quantity, manufacturer, supplier_id, category_id, expiry_date) VALUES 
('Paracetamol', 'Pain reliever and fever reducer', 5.99, 3.99, 100, 'Generic Pharma', 1, 2, '2024-12-31'),
('Amoxicillin', 'Antibiotic', 12.99, 8.99, 50, 'MediCorp', 2, 1, '2024-06-30'),
('Ibuprofen', 'Anti-inflammatory', 7.99, 4.99, 75, 'HealthCare Ltd', 3, 2, '2024-09-30')
ON DUPLICATE KEY UPDATE id=id;

-- Insert sample customers
INSERT INTO customers (name, phone, email, address) VALUES
('Sarah Johnson', '1112223333', 'sarah@email.com', '321 Patient St, Medical City'),
('Robert Brown', '4445556666', 'robert@email.com', '654 Customer Ave, Health Town'),
('Emily Davis', '7778889999', 'emily@email.com', '987 Client Rd, Care City')
ON DUPLICATE KEY UPDATE id=id;

-- Insert sample roles
INSERT INTO roles (name, description) VALUES
('admin', 'Full system access'),
('pharmacist', 'Manage medicines and orders'),
('cashier', 'Handle sales and payments')
ON DUPLICATE KEY UPDATE id=id;

-- Assign roles to admin user
INSERT INTO user_roles (user_id, role_id) 
SELECT u.id, r.id FROM users u, roles r 
WHERE u.username = 'admin' AND r.name = 'admin'
ON DUPLICATE KEY UPDATE user_id=user_id;

-- Add prescription table for tracking prescriptions
CREATE TABLE IF NOT EXISTS prescriptions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    doctor_name VARCHAR(100),
    hospital_name VARCHAR(100),
    prescription_date DATE,
    image_path VARCHAR(255),
    notes TEXT,
    status ENUM('pending', 'verified', 'dispensed', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

-- Add medicine composition table
CREATE TABLE IF NOT EXISTS medicine_compositions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    medicine_id INT NOT NULL,
    ingredient_name VARCHAR(100) NOT NULL,
    strength VARCHAR(50),
    unit VARCHAR(20),
    FOREIGN KEY (medicine_id) REFERENCES medicines(id)
);

-- Add medicine dosage instructions
CREATE TABLE IF NOT EXISTS medicine_instructions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    medicine_id INT NOT NULL,
    dosage_form VARCHAR(50), -- tablet, syrup, injection, etc.
    route VARCHAR(50), -- oral, topical, etc.
    frequency VARCHAR(100), -- how often to take
    special_instructions TEXT,
    side_effects TEXT,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id)
);

-- Add returns/refunds table
CREATE TABLE IF NOT EXISTS returns (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    customer_id INT,
    return_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reason TEXT,
    status ENUM('pending', 'approved', 'rejected', 'completed') DEFAULT 'pending',
    refund_amount DECIMAL(10,2),
    processed_by INT,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (processed_by) REFERENCES users(id)
);

-- Add return items table
CREATE TABLE IF NOT EXISTS return_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    return_id INT,
    medicine_id INT,
    quantity INT,
    price_per_unit DECIMAL(10,2),
    subtotal DECIMAL(10,2),
    reason TEXT,
    FOREIGN KEY (return_id) REFERENCES returns(id),
    FOREIGN KEY (medicine_id) REFERENCES medicines(id)
);

-- Add tax rates table
CREATE TABLE IF NOT EXISTS tax_rates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    rate DECIMAL(5,2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add discounts table
CREATE TABLE IF NOT EXISTS discounts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    type ENUM('percentage', 'fixed') NOT NULL,
    value DECIMAL(10,2) NOT NULL,
    start_date DATE,
    end_date DATE,
    minimum_purchase DECIMAL(10,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add medicine alternatives table
CREATE TABLE IF NOT EXISTS medicine_alternatives (
    id INT PRIMARY KEY AUTO_INCREMENT,
    medicine_id INT NOT NULL,
    alternative_medicine_id INT NOT NULL,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id),
    FOREIGN KEY (alternative_medicine_id) REFERENCES medicines(id)
);

-- Add some sample data
INSERT INTO tax_rates (name, rate) VALUES
('Standard VAT', 7.00),
('Reduced VAT', 3.00)
ON DUPLICATE KEY UPDATE id=id;

INSERT INTO discounts (name, type, value, minimum_purchase) VALUES
('Senior Citizen', 'percentage', 20.00, 0),
('Bulk Purchase', 'percentage', 10.00, 1000),
('New Customer', 'fixed', 50.00, 500)
ON DUPLICATE KEY UPDATE id=id;

-- Create payment_logs table for tracking payment processing steps
CREATE TABLE IF NOT EXISTS payment_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    payment_id INT,
    status VARCHAR(50),
    message TEXT,
    log_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(id)
);

-- Create crypto_payments table for cryptocurrency transactions
CREATE TABLE IF NOT EXISTS crypto_payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    payment_id INT,
    wallet_address VARCHAR(255),
    crypto_currency VARCHAR(20),
    amount_in_crypto DECIMAL(18,8),
    transaction_hash VARCHAR(255),
    block_confirmation_count INT DEFAULT 0,
    status ENUM('pending', 'confirmed', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(id)
);

-- Create payment_settings table
CREATE TABLE IF NOT EXISTS payment_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    provider VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    config_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert sample payment settings
INSERT INTO payment_settings (provider, is_active, config_data) VALUES
('stripe', true, '{"public_key": "pk_test_xxx", "secret_key": "sk_test_xxx", "webhook_secret": "whsec_xxx"}'),
('crypto', true, '{"ethereum_node": "https://mainnet.infura.io/v3/YOUR-PROJECT-ID", "contract_address": "0x..."}'),
('qr_code', true, '{"merchant_id": "MERCHANT123", "terminal_id": "TERM123"}')
ON DUPLICATE KEY UPDATE id=id;

-- Create payment_refunds table
CREATE TABLE IF NOT EXISTS payment_refunds (
    id INT PRIMARY KEY AUTO_INCREMENT,
    payment_id INT,
    amount DECIMAL(10,2),
    reason TEXT,
    refund_transaction_id VARCHAR(100),
    status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    processed_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(id),
    FOREIGN KEY (processed_by) REFERENCES users(id)
);

-- Insert sample data for testing
INSERT INTO medicines (name, description, price, quantity) VALUES
('Paracetamol', 'Pain reliever and fever reducer', 5.99, 8),
('Amoxicillin', 'Antibiotic', 12.99, 15),
('Ibuprofen', 'Pain reliever', 7.99, 3),
('Aspirin', 'Pain reliever', 4.99, 20),
('Cetirizine', 'Allergy medication', 8.99, 5);

INSERT INTO orders (customer_name, total_amount, status) VALUES
('John Doe', 35.97, 'Completed'),
('Jane Smith', 25.98, 'Completed'),
('Mike Johnson', 12.99, 'Pending'),
('Sarah Williams', 47.95, 'Completed'),
('Tom Brown', 15.98, 'Cancelled');