<?php
session_start();
require_once "config.php";

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Process delete operation
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    $sql = "DELETE FROM customers WHERE id = :id";
    
    if($stmt = $pdo->prepare($sql)){
        $stmt->bindParam(":id", $param_id);
        $param_id = trim($_GET["id"]);
        
        if($stmt->execute()){
            header("location: customers.php");
            exit();
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
}

header("location: customers.php");
exit();
?> 