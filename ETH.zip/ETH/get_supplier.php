<?php
require_once "config.php";

if(isset($_GET['id'])) {
    $sql = "SELECT * FROM suppliers WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$_GET['id']]);
    $supplier = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($supplier);
}
?> 