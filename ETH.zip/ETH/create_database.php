<?php
$host = 'localhost';
$username = 'root';
$password = '';

try {
    // Create connection without database
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Read SQL file
    $sql = file_get_contents('database.sql');
    
    // Execute SQL commands
    $pdo->exec($sql);
    
    echo "Database and tables created successfully!";
    
} catch(PDOException $e) {
    echo "Error creating database: " . $e->getMessage();
}
?> 